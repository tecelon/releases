#!/usr/bin/env bash
# hosts-behind.sh, played with the hosts an instance can have (intent 0ea6f919). Run by verify.sh.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FLOOR=2026.10.23.3
IMAGE=ghcr.io/tecelon/control-plane/host-agent:2026.10.23.3
US=$'\x1f'
row() { local IFS="$US"; printf '%s\n' "$*"; }
failures=0
check() {
  local what="$1" want_exit="$2" want="$3" input="$4" out code=0
  out=$(printf '%s' "$input" | K3D_NODES="${K3D_NODES:-}" "$here/hosts-behind.sh" "$FLOOR" "$IMAGE") || code=$?
  if [ "$code" != "$want_exit" ] || [ "$out" != "$want" ]; then
    printf 'FAIL %s\n  exit %s, wanted %s\n  got:\n%s\n  wanted:\n%s\n' "$what" "$code" "$want_exit" "$out" "$want" >&2
    failures=$((failures + 1))
  else
    printf 'ok   %s\n' "$what"
  fi
}

# The owner's, on 25 Oct: a cluster host whose agent never updated from 2026.10.19.3.
check "a cluster host from before the floor is named, with its kubectl line" 1 \
"  Cluster: its agent is 2026.10.19.3.
    On the cluster: kubectl -n control-plane set image deploy/control-plane-host agent=$IMAGE" \
  "$(row Cluster kubernetes ghcr.io/tecelon/control-plane/host-agent:2026.10.19.3 '' '')"

check "where its agent says its namespace and deployment, they are used" 1 \
"  Lab: its agent is 2026.10.23.2.
    On the cluster: kubectl -n lab set image deploy/control-plane-host-agent agent=$IMAGE" \
  "$(row Lab kubernetes ghcr.io/tecelon/control-plane/host-agent:2026.10.23.2 lab control-plane-host-agent)"

# The owner's Mac, 26 Oct: k3d's cluster on the same computer, where the host's kubectl knows nothing of it.
K3D_NODES=k3d-control-plane-server-0 check "a k3d host here, its agent too old to name its node, is updated inside the one k3d node here" 1 \
"  mac2: its agent is 2026.10.19.
    On this computer: docker exec k3d-control-plane-server-0 kubectl -n control-plane set image deploy/control-plane-host agent=$IMAGE" \
  "$(row mac2 kubernetes ghcr.io/tecelon/control-plane/host-agent:2026.10.19 '' '')"

K3D_NODES="k3d-a-server-0 k3d-b-server-0" check "one naming its node is updated inside it" 1 \
"  B: its agent is 2026.10.23.2.
    On this computer: docker exec k3d-b-server-0 kubectl -n control-plane set image deploy/control-plane-host-agent agent=$IMAGE" \
  "$(row B kubernetes x/host-agent:2026.10.23.2 control-plane control-plane-host-agent k3d-b-server-0)"

check "a k3d cluster on another computer is updated inside its node there" 1 \
"  Far: its agent is 2026.10.23.2.
    On the computer its cluster runs on: docker exec k3d-far-server-0 kubectl -n control-plane set image deploy/control-plane-host agent=$IMAGE" \
  "$(row Far kubernetes x/host-agent:2026.10.23.2 control-plane control-plane-host k3d-far-server-0)"

check "a Docker host behind is sent to its new connection command" 1 \
"  Desk: its agent is 2026.10.22.3.
    In the console: Hosts → Desk → New connection command, then run it on that computer." \
  "$(row Desk docker ghcr.io/tecelon/control-plane/host-agent:2026.10.22.3 '' '')"

check "an agent that does not say which it is counts as behind" 1 \
"  Old: its agent is too old to say which it is.
    In the console: Hosts → Old → New connection command, then run it on that computer." \
  "$(row Old '' '' '' '')"

check "the floor itself, and later, go on" 0 "" \
  "$(row A docker x/host-agent:2026.10.23.3 '' '')
$(row B kubernetes x/host-agent:2026.10.24.2 ns d)
$(row C docker x/host-agent:2026.11.01 '' '')"

check "an agent built from a checkout cannot be told apart, and goes on" 0 "" \
  "$(row Dev docker localhost:5000/control-plane/host-agent:latest '' '')"

check "no hosts go on" 0 "" ""

check "only those behind are named, among others" 1 \
"  Old: its agent is 2026.10.19.3.
    In the console: Hosts → Old → New connection command, then run it on that computer." \
  "$(row New docker x/host-agent:2026.10.24.2 '' '')
$(row Old docker x/host-agent:2026.10.19.3 '' '')"

code=0; "$here/hosts-behind.sh" --query 'hosts; drop table x' >/dev/null 2>&1 || code=$?
if [ "$code" = 2 ]; then printf 'ok   the query takes a plain table name only\n'; else printf 'FAIL the query took a table that is not a plain name (exit %s)\n' "$code" >&2; failures=$((failures + 1)); fi

# The installer's own query, on a Postgres where there is one (verify.sh starts one): the columns it reads are
# the hosts table's, an empty field stays a field, and a host pending or revoked is not asked about.
if [ -n "${TEST_PG_ADMIN_URL:-}" ] && command -v psql >/dev/null 2>&1; then
  db="hosts_behind_$$"
  url="${TEST_PG_ADMIN_URL%/*}/$db"
  psql "$TEST_PG_ADMIN_URL" -XqAt -c "create database $db" >/dev/null
  trap 'psql "$TEST_PG_ADMIN_URL" -XqAt -c "drop database if exists $db" >/dev/null 2>&1 || true' EXIT
  psql "$url" -Xq -v ON_ERROR_STOP=1 >/dev/null <<'SQL'
create table hosts (id serial primary key, name text not null, status text not null default 'pending', info jsonb);
insert into hosts (name, status, info) values
  ('Cluster', 'online', '{"runtime": {"kind": "kubernetes", "capabilities": {}}, "agent_image": "ghcr.io/tecelon/control-plane/host-agent:2026.10.19.3"}'),
  ('Current', 'offline', '{"runtime": {"kind": "docker"}, "agent_image": "x/host-agent:2026.10.24.2", "agent_namespace": null}'),
  ('Pending', 'pending', null),
  ('Revoked', 'revoked', '{"agent_image": "x/host-agent:2026.10.01"}'),
  ('Silent', 'offline', '{"agent_version": "0.1.0"}');
SQL
  rows=$(psql "$url" -XAt -F $'\x1f' -c "$("$here/hosts-behind.sh" --query)")
  check "the installer's query, on Postgres" 1 \
"  Cluster: its agent is 2026.10.19.3.
    On the cluster: kubectl -n control-plane set image deploy/control-plane-host agent=$IMAGE
  Silent: its agent is too old to say which it is.
    In the console: Hosts → Silent → New connection command, then run it on that computer." "$rows"

  # A database from before the rename's step 6 (intent 6db326fd), as an upgrade from 2026.11.10 finds it: no hosts
  # table, the same rows in the table under its name before (runners). Read as install.sh reads it, the new name first.
  before="hosts_behind_before_$$"
  psql "$TEST_PG_ADMIN_URL" -XqAt -c "create database $before" >/dev/null
  trap 'psql "$TEST_PG_ADMIN_URL" -XqAt -c "drop database if exists $db" >/dev/null 2>&1 || true; psql "$TEST_PG_ADMIN_URL" -XqAt -c "drop database if exists $before" >/dev/null 2>&1 || true' EXIT
  psql "${TEST_PG_ADMIN_URL%/*}/$before" -Xq -v ON_ERROR_STOP=1 >/dev/null <<'SQL'
create table runners (id serial primary key, name text not null, status text not null default 'pending', info jsonb);
insert into runners (name, status, info) values
  ('Desk', 'offline', '{"runtime": {"kind": "docker"}, "agent_image": "x/host-agent:2026.10.22.3"}'),
  ('Current', 'online', '{"runtime": {"kind": "docker"}, "agent_image": "x/host-agent:2026.11.10"}');
SQL
  rows=$(for table in hosts runners; do
    psql "${TEST_PG_ADMIN_URL%/*}/$before" -XAt -F $'\x1f' -c "$("$here/hosts-behind.sh" --query "$table")" 2>/dev/null && break
  done)
  check "the installer's query, on a database from before the rename (runners)" 1 \
"  Desk: its agent is 2026.10.22.3.
    In the console: Hosts → Desk → New connection command, then run it on that computer." "$rows"
else
  echo "skip the installer's query: no TEST_PG_ADMIN_URL and psql"
fi

[ "$failures" = 0 ] || { echo "hosts-behind: $failures failed" >&2; exit 1; }
