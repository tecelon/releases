#!/usr/bin/env bash
# Which of an instance's hosts have an agent older than the release about to be installed still
# answers (intent 0ea6f919). Such a host cannot connect after the upgrade, and then nothing from the
# control plane reaches it: it is updated by hand first, with the command printed for it.
#
#   hosts-behind.sh <floor> <agent image> < hosts
#
# Each line of hosts: name, runtime kind, agent image, agent namespace, agent deployment, agent node, separated by the
# unit separator (\x1f: a tab is whitespace to `read`, and two in a row would lose an empty field), each empty
# where the agent did not say. <floor> is the oldest release whose agent is still answered; <agent image> the
# one to put on a cluster's host by hand. Prints one block per host behind; exits 1 when any is.
#
# A cluster k3d made on this computer runs kubectl inside its node, a Docker container: the node its agent names
# (k3d-<cluster>-server-0), or, for an agent too old to name it, the one k3d node container this computer has
# (K3D_NODES, space-separated, as install.sh finds them).
#
#   hosts-behind.sh --query [table]   # the SQL that lists them, from the sandboxes service's database
#
# The table is hosts unless said: install.sh names the one a release from before the rename's step 6 (intent
# 6db326fd) keeps them in, which it reads before it upgrades it.
set -euo pipefail

if [ "${1:-}" = --query ]; then
  table="${2:-hosts}"
  [[ "$table" =~ ^[a-z_]+$ ]] || { echo "the table is a plain name" >&2; exit 2; }
  # Every host that has ever said what it is, and is not revoked: one offline now still comes back.
  echo "select name, coalesce(info #>> '{runtime,kind}', ''), coalesce(info ->> 'agent_image', ''),
  coalesce(info ->> 'agent_namespace', ''), coalesce(info ->> 'agent_deployment', ''), coalesce(info ->> 'agent_node', '')
  from $table where status <> 'revoked' and info is not null order by name"
  exit 0
fi
floor="$1"
image="$2"
behind=0
# A last line with no newline after it is read too.
while IFS=$'\x1f' read -r name kind agent ns deployment node || [ -n "${name:-}" ]; do
  [ -n "$name" ] || continue
  if [ -n "$agent" ]; then
    tag=""
    case "$agent" in *:*) tag="${agent##*:}" ;; esac
    # A release's tag says how old it is; any other (latest, a commit) was built from a checkout, and is let be.
    [[ "$tag" =~ ^[0-9]{4}\.[0-9]{2}\.[0-9]{2}(\.[0-9]+)?$ ]] || continue
    [ "$tag" != "$floor" ] || continue
    [ "$(printf '%s\n%s\n' "$tag" "$floor" | sort -V | head -1)" = "$tag" ] || continue
    was="its agent is $tag"
  else
    # An agent too old to say what it runs is older than any floor.
    was="its agent is too old to say which it is"
  fi
  behind=1
  printf '  %s: %s.\n' "$name" "$was"
  if [ "$kind" = kubernetes ]; then
    kubectl="kubectl -n ${ns:-control-plane} set image deploy/${deployment:-control-plane-host} agent=$image"
    # shellcheck disable=SC2086
    set -- ${K3D_NODES:-}
    if [ -n "$node" ] && [[ " ${K3D_NODES:-} " == *" $node "* ]]; then
      printf '    On this computer: docker exec %s %s\n' "$node" "$kubectl"
    elif [[ "$node" == k3d-* ]]; then
      printf '    On the computer its cluster runs on: docker exec %s %s\n' "$node" "$kubectl"
    elif [ -z "$node" ] && [ "$#" = 1 ]; then
      printf '    On this computer: docker exec %s %s\n' "$1" "$kubectl"
    else
      printf '    On the cluster: %s\n' "$kubectl"
    fi
  else
    printf '    In the console: Hosts → %s → New connection command, then run it on that computer.\n' "$name"
  fi
done
exit "$behind"
