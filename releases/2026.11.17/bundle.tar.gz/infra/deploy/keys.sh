# shellcheck shell=bash
# The secrets a control plane stack can make for itself, written into its env file
# (ENV_FILE) when they are not there. Sourced by deploy.sh and by
# ../stack/provision.sh, so both make them the same way. Prints only names,
# never values.

_keys_said() { printf '  \033[32m✓\033[0m %s\n' "$1"; }

# The keys providers are given for their callers (intent a6481bfa, acceptance 10), `<CALLER>_<PROVIDER>_KEY`, beside
# the tasks provider's three that phase 1 made; and each database's role's password (acceptance 12),
# `<DATABASE>_DB_PASSWORD`, as compose's db-init names them. keys.test.sh reads both.
CALLER_KEY_NAMES="CONSOLE_TENANTS_KEY SANDBOXES_TENANTS_KEY AGENTS_TENANTS_KEY SANDBOXES_INTENTS_KEY \
CONSOLE_PRIMITIVES_KEY AGENTS_PRIMITIVES_KEY SANDBOXES_PRIMITIVES_KEY SANDBOXES_TASKS_KEY \
AGENTS_MCP_GATEWAY_KEY SANDBOXES_MCP_GATEWAY_KEY"
DATABASE_PASSWORD_NAMES="SESSIONS_DB_PASSWORD TASKS_DB_PASSWORD MCP_AUDIT_DB_PASSWORD GATEWAY_DB_PASSWORD \
AGENTS_DB_PASSWORD TENANTS_DB_PASSWORD CREDENTIALS_DB_PASSWORD WORKERS_DB_PASSWORD INTENTS_DB_PASSWORD \
INCIDENTS_DB_PASSWORD PRIMITIVES_DB_PASSWORD RAUTHY_DB_PASSWORD KEYCLOAK_DB_PASSWORD CONSOLE_DB_PASSWORD \
PROVIDER_RUNTIME_DB_PASSWORD"

# Appended when the variable has no line at all; a line that is there, even an
# empty one, is left alone (deploy.sh's behaviour since it was written).
ensure_env() {
  grep -q "^$1=" "$ENV_FILE" || { printf '%s=%s\n' "$1" "$2" >> "$ENV_FILE"; _keys_said "generated $1"; }
}

# Filled when the variable is missing or empty: for a fresh box's env file,
# which lists the variables with no values (../stack/.env.example).
fill_env() {
  grep -q "^$1=." "$ENV_FILE" && return 0
  if grep -q "^$1=\$" "$ENV_FILE"; then
    # Through the environment rather than awk -v, which would read escapes in it.
    # The temporary copy holds every secret too: private from the start.
    ( umask 077; KEY="$1" VALUE="$2" awk 'BEGIN { FS = "=" } $0 == ENVIRON["KEY"] "=" { print ENVIRON["KEY"] "=" ENVIRON["VALUE"]; next } { print }' \
      "$ENV_FILE" > "$ENV_FILE.tmp" ) && cat "$ENV_FILE.tmp" > "$ENV_FILE" && rm -f "$ENV_FILE.tmp"
  else
    printf '%s=%s\n' "$1" "$2" >> "$ENV_FILE"
  fi
  _keys_said "generated $1"
}

# Settings under their names before the renames, each with its name now: intent 6db326fd's first (the dial address
# and the bridge's by the owner's choice 3.1), then intent 683b273e's, so a file that says one under both of its old
# names keeps the later. HOST_AGENT_IMAGE and AUTO_UPDATE_HOSTS were names before 683b273e and are again:
# they are never moved away. Kept for good, as they cost nothing and an instance can jump a release. install.sh moves
# an instance's file by the same list.
RENAMED_SETTINGS="RUNNER_URL:HOST_DIAL_URL RUNNER_BIND:BRIDGE_ADDRESS RUNNER_NAMING:HOST_NAMING \
RUNNER_LOCAL_PORT:HOST_LOCAL_PORT RUNNER_IMAGES:HOST_IMAGES RUNNER_TAG:HOST_IMAGES_TAG \
RUNNER_AGENT_IMAGE:HOST_AGENT_IMAGE OPERATORS_RUNNER:OPERATORS_HOST AUTO_UPDATE_RUNNERS:AUTO_UPDATE_HOSTS \
MACHINE_URL:HOST_DIAL_URL MACHINE_BIND:BRIDGE_ADDRESS MACHINE_NAMING:HOST_NAMING MACHINE_LOCAL_PORT:HOST_LOCAL_PORT \
MACHINE_IMAGES:HOST_IMAGES MACHINE_TAG:HOST_IMAGES_TAG APPS_DOMAIN:ARTIFACTS_DOMAIN OPERATORS_MACHINE:OPERATORS_HOST \
OTEL_WORKER_ENDPOINT:OTEL_SANDBOX_ENDPOINT WORKER_TOOL_PACKS:SANDBOX_TOOL_PACKS WORKER_IMAGE:SANDBOX_IMAGE \
WORKERS_MCP_URL:SANDBOXES_MCP_URL WORKER_GRACE_MS:SANDBOX_GRACE_MS TAG_WORKERS:TAG_SANDBOXES \
WORKERS_HOST_PORT:SANDBOXES_HOST_PORT"

# The box's env file in those names now, with what they say: the box goes on as it was, and once the rename's window
# closes the services and the compose file read only the new ones. A line under the old name becomes the new one
# only where the new one has none; names are said, never values.
rename_old_settings() {
  local pair old new
  for pair in $RENAMED_SETTINGS; do
    old="${pair%%:*}"; new="${pair#*:}"
    grep -q "^$old=." "$ENV_FILE" && ! grep -q "^$new=." "$ENV_FILE" || continue
    # Any empty line under the new name goes, so the file says it once.
    ( umask 077; OLD="$old" NEW_NAME="$new" awk 'BEGIN { FS = "=" } $0 == ENVIRON["NEW_NAME"] "=" { next } $1 == ENVIRON["OLD"] { $0 = ENVIRON["NEW_NAME"] substr($0, length(ENVIRON["OLD"]) + 1) } { print }' \
      "$ENV_FILE" > "$ENV_FILE.tmp" ) && cat "$ENV_FILE.tmp" > "$ENV_FILE" && rm -f "$ENV_FILE.tmp"
    _keys_said "$old is $new now"
  done
}

ec_key() { openssl ecparam -name prime256v1 -genkey -noout 2>/dev/null | openssl pkcs8 -topk8 -nocrypt 2>/dev/null | base64 | tr -d '\n'; }

# Per-service signing keys and session secrets. Each service signs as itself; a
# leaked key lets an attacker sign only as that one service, to the services
# that trust it.
ensure_service_keys() {
  for svc in CHANNEL_GATEWAY MCP_GATEWAY AGENTS RUNTIME SESSIONS TENANTS WORKERS; do ensure_env "SIGNING_KEY_$svc" "$(ec_key)"; done
  # One secret per provider (intent afe0ae46), in place of ADMIN_SECRET, which opens every control-plane admin route:
  # a leaked one opens that provider's admin API, and of the control plane's only its own callback routes. Filled
  # where the file has none or an empty one, as at every deploy, install and provision, before compose reads the file:
  # compose gives no provider the admin secret in place of its own (intent d0218d38), and stops, naming it, where one
  # is unset. Core (tenants) has its own too (intent a6481bfa), given only to the services that call its admin routes.
  # The provider runtime's own (intent 1895ea55), which opens its own API alone and the console alone holds, is made the
  # same way on every instance, with or without a driver: compose names it either way.
  for secret in INTENTS_SECRET INCIDENTS_SECRET IMPACT_SECRET PRIMITIVES_SECRET TASKS_SECRET AGENTS_REGISTRY_SECRET MCP_GATEWAY_SECRET TENANTS_SECRET PROVIDER_RUNTIME_SECRET; do
    fill_env "$secret" "$(openssl rand -hex 32)"
  done
  # And each key a provider is given for a caller to read with (intent a6481bfa): the impact service reads intents and
  # incidents with one each, which opens their GET routes alone, never their own secrets; sessions and the channel
  # gateway one each, which opens directory/1's project read by its id alone, to know a project is there.
  local reader
  for reader in IMPACT_INTENTS_READ_KEY IMPACT_INCIDENTS_READ_KEY SESSIONS_TENANTS_READ_KEY CHANNEL_GATEWAY_TENANTS_READ_KEY; do
    fill_env "$reader" "$(openssl rand -hex 32)"
  done
  # What the tasks service seals the token each task fires with by (intent afe0ae46, phase 3): a key of its own, never
  # CREDENTIALS_KEY. Until a deploy or install makes it, the service keeps no tokens.
  fill_env TASKS_CREDENTIALS_KEY "$(openssl rand -base64 32 | tr -d '\n')"
  # The tasks provider's keys for the conversation module's services and the console's Tasks page (intent a6481bfa:
  # every caller its own key), given to the provider as its CALLER_KEYS and to each as its TASKS_KEY.
  # And every other key a provider is given for a caller of its own (acceptance 10), where more than one service calls
  # it: core's, the intents provider's, primitives', the tasks provider's and the MCP gateway's, each caller its own, so
  # no two hold the same and each provider's own secret is held by at most one caller (`CALLER_KEYS`).
  local caller_key
  for caller_key in CHANNEL_GATEWAY_TASKS_KEY AGENTS_TASKS_KEY CONSOLE_TASKS_KEY $CALLER_KEY_NAMES; do
    fill_env "$caller_key" "$(openssl rand -hex 32)"
  done
  # Each database's role's password (intent a6481bfa, acceptance 12): hex, as it is written inside a URL. db-init sets
  # it on the role at every start, so one changed here follows.
  local database
  for database in $DATABASE_PASSWORD_NAMES; do
    fill_env "$database" "$(openssl rand -hex 24)"
  done
  # The MCP gateway seals its servers' secrets with its own key (intent 4bedc187), never the core's.
  fill_env MCP_GATEWAY_CREDENTIALS_KEY "$(openssl rand -base64 32 | tr -d '\n')"
  # And each service that seals secrets of its own, with a key of its own that no other service holds (intent a6481bfa):
  # the channel gateway its channels' tokens, the sandboxes service projects' secrets and artifacts' and events' tokens,
  # the console the voice providers' keys, the agents service its copy of its servers' keys until it is dropped. Each
  # is given CREDENTIALS_KEY, the key they once shared, beside it for one release, and reseals with its own as it starts.
  local sealing_key
  for sealing_key in CHANNEL_GATEWAY_CREDENTIALS_KEY SANDBOXES_CREDENTIALS_KEY CONSOLE_CREDENTIALS_KEY AGENTS_CREDENTIALS_KEY; do
    fill_env "$sealing_key" "$(openssl rand -base64 32 | tr -d '\n')"
  done
  # The credentials provider (intent a6481bfa, phase 3), where people's accounts are kept: its own secret, which no
  # service holds; the key it seals each credential with, its alone (never another service's sealing key; lost, every
  # credential kept there is lost with it); and each caller's own key there, the provider runtime's among them (intent
  # 1895ea55: where a driver's settings keep their secrets).
  fill_env CREDENTIALS_SECRET "$(openssl rand -hex 32)"
  fill_env CREDENTIALS_SEALING_KEY "$(openssl rand -base64 32 | tr -d '\n')"
  local accounts_key
  for accounts_key in CONSOLE_ACCOUNTS_KEY SANDBOXES_ACCOUNTS_KEY AGENTS_ACCOUNTS_KEY PROVIDER_RUNTIME_ACCOUNTS_KEY; do
    fill_env "$accounts_key" "$(openssl rand -hex 32)"
  done
  # Nothing reads it now that n8n has left, but compose still requires it: a fresh file must not fail the deploy.
  ensure_env N8N_SIGNING_SECRET "$(openssl rand -hex 24)"
  ensure_env CONSOLE_SESSION_SECRET "$(openssl rand -base64 36 | tr -d '\n')"
}

# What a person used to choose by hand for a new box. Generated only where the
# file has nothing; hex where the value ends up inside a URL (the database's).
ensure_first_boot_secrets() {
  fill_env POSTGRES_PASSWORD "$(openssl rand -hex 24)"
  fill_env ADMIN_SECRET "$(openssl rand -hex 32)"
  fill_env CREDENTIALS_KEY "$(openssl rand -base64 32 | tr -d '\n')"
  fill_env CONSOLE_PASSWORD "$(openssl rand -hex 16)"
  fill_env REGISTRY_PASSWORD "$(openssl rand -hex 24)"
}

# A value derived from others, written over whatever is there: it follows them.
set_derived() {
  if grep -q "^$1=" "$ENV_FILE"; then
    [ "$(sed -n "s/^$1=//p" "$ENV_FILE" | tail -1)" = "$2" ] && return 0
    ( umask 077; KEY="$1" VALUE="$2" awk 'BEGIN { FS = "=" } $1 == ENVIRON["KEY"] { print ENVIRON["KEY"] "=" ENVIRON["VALUE"]; next } { print }' \
      "$ENV_FILE" > "$ENV_FILE.tmp" ) && cat "$ENV_FILE.tmp" > "$ENV_FILE" && rm -f "$ENV_FILE.tmp"
  else
    printf '%s=%s\n' "$1" "$2" >> "$ENV_FILE"
  fi
}
_env_value() { sed -n "s/^$1=//p" "$ENV_FILE" | tail -1; }

# Where intents/2 is served (intent 1895ea55): by the native provider, or, where INTENTS_DRIVER names a driver (its name,
# `intents-jira`, a program `provider-driver-intents-jira` in the provider runtime's image; or a path to one there), by
# the provider runtime that hosts it, at its address for intents. Written to INTENTS_URL at every run, which every
# caller of intents reads (the console, the sandboxes service, impact, the edge), so it follows INTENTS_DRIVER; the
# deploy's compose profiles start the one and not the other (infra/stack/lib.sh, deploy.sh). Says which, never a secret.
INTENTS_NATIVE_URL=http://intents:3100
INTENTS_RUNTIME_URL=http://provider-runtime:3100
provider_settings() {
  local driver; driver=$(_env_value INTENTS_DRIVER)
  case "$driver" in
    '') set_derived INTENTS_URL "$INTENTS_NATIVE_URL"; _keys_said "intents: the native provider"; return 0 ;;
    /*) case "$driver" in *[!A-Za-z0-9._/-]*) driver= ;; esac ;;
    *) case "$driver" in -* | *[!a-z0-9-]*) driver= ;; esac; [ "${#driver}" -le 64 ] || driver= ;;
  esac
  if [ -z "$driver" ]; then
    printf '  \033[31m✗ INTENTS_DRIVER is a driver'"'"'s name (lowercase letters, digits and -, as intents-jira) or the path of its program in the provider runtime'"'"'s image\033[0m\n' >&2
    return 1
  fi
  set_derived INTENTS_URL "$INTENTS_RUNTIME_URL"
  _keys_said "intents: the driver $driver, in the provider runtime"
}

# Rauthy's own secrets: its cache's, its encryption key, its admin, and the API
# key tenants uses, its only admin client (64 characters, as Rauthy wants); and
# the password of the one person the browser suite signs in as.
ensure_idp_keys() {
  ensure_env IDP_SECRET_RAFT "$(openssl rand -hex 32)"
  ensure_env IDP_SECRET_API "$(openssl rand -hex 32)"
  ensure_env IDP_ENC_KEY_ID "$(openssl rand -hex 8)"
  ensure_env IDP_ENC_KEY "$(openssl rand -base64 32 | tr -d '\n')"
  ensure_env IDP_ADMIN_PASSWORD "$(openssl rand -hex 16)"
  ensure_env IDP_API_KEY_SECRET "$(openssl rand -hex 32)"
  # The browser suite's own person's (the owner, 8 Nov 2026: a member of the end-to-end organisation only, no
  # platform admin), which scripts/e2e.sh makes them in Rauthy with, or gives them, before each run. Filled where
  # missing or empty; 52 characters, an upper and a lower case letter, a digit and a sign before the random hex, as
  # Rauthy's password policy asks.
  fill_env E2E_PERSON_PASSWORD "E2e-$(openssl rand -hex 24)"
}

# Where the instance's sign-in (Rauthy) is, for the services that use it,
# written each run so it follows a change of address. Names only are printed.
#
# Rauthy is the only sign-in. An env file from before says SIGN_IN=keycloak, or
# nothing (an instance installed before Rauthy): it is on Rauthy all the same,
# its people brought from what Keycloak left in its database at Rauthy's first
# start (idp-init). SIGN_IN=rauthy is written for a release from before this
# one, installed over it again: that one reads it, and stays on Rauthy rather
# than going back to a Keycloak nobody has signed in to since.
sign_in_settings() {
  local public host
  public=$(_env_value PUBLIC_URL); public=${public%/}
  host=${public#*://}; host=${host%%/*}
  set_derived SIGN_IN rauthy
  set_derived SIGN_IN_ISSUER "$public/auth/v1/"
  set_derived SIGN_IN_INTERNAL_URL "http://idp:8080/auth/v1"
  # (SIGN_IN_MCP_ISSUER and SIGN_IN_MCP_JWKS are no longer written: nothing read them since the MCP gateway issues its
  # own tokens, intent 4bedc187. An env file from before keeps them, unread.)
  # Rauthy's own view of where it is: the host people reach, and whether nginx in front speaks https for it.
  set_derived IDP_PUB_URL "$host"
  set_derived IDP_RP_ID "${host%%:*}"
  # Its passkeys' origin, which Rauthy refuses to start without a port in:
  # https://agents.example.com has none, so the scheme's own is written out.
  case "$host" in
    *:*) set_derived IDP_RP_ORIGIN "${public%%://*}://$host" ;;
    *) set_derived IDP_RP_ORIGIN "${public%%://*}://$host:$([ "${public%%://*}" = https ] && echo 443 || echo 80)" ;;
  esac
  case "$public" in
    https://*) set_derived IDP_PROXY_MODE true; set_derived IDP_COOKIE_MODE host ;;
    *) set_derived IDP_PROXY_MODE false; set_derived IDP_COOKIE_MODE danger-insecure ;;
  esac
  _keys_said "sign-in: Rauthy"
}
