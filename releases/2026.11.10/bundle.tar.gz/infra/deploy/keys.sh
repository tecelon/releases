# shellcheck shell=bash
# The secrets a control plane stack can make for itself, written into its env file
# (ENV_FILE) when they are not there. Sourced by deploy.sh and by
# ../stack/provision.sh, so both make them the same way. Prints only names,
# never values.

_keys_said() { printf '  \033[32m✓\033[0m %s\n' "$1"; }

# Appended when the variable has no line at all; a line that is there, even an
# empty one, is left alone (deploy.sh's behaviour since it was written).
ensure_env() {
  grep -q "^$1=" "$ENV_FILE" || { printf '%s=%s\n' "$1" "$2" >> "$ENV_FILE"; _keys_said "generated $1"; }
}

# Filled when the variable is missing or empty: for a fresh box's env file,
# which lists the variables with no values (../stack/.env.example).
fill_env() {
  grep -q "^$1=." "$ENV_FILE" && return 0
  if grep -q "^$1=\$" "$ENV_FILE"; then
    # Through the environment rather than awk -v, which would read escapes in it.
    # The temporary copy holds every secret too: private from the start.
    ( umask 077; KEY="$1" VALUE="$2" awk 'BEGIN { FS = "=" } $0 == ENVIRON["KEY"] "=" { print ENVIRON["KEY"] "=" ENVIRON["VALUE"]; next } { print }' \
      "$ENV_FILE" > "$ENV_FILE.tmp" ) && cat "$ENV_FILE.tmp" > "$ENV_FILE" && rm -f "$ENV_FILE.tmp"
  else
    printf '%s=%s\n' "$1" "$2" >> "$ENV_FILE"
  fi
  _keys_said "generated $1"
}

# Settings from before the rename (intent 683b273e) under their new names, with what they say: the box goes on
# as it was, and once the window closes the services and the compose file read only the new ones. A line under
# the old name becomes the new one only where the new one has none; names are said, never values.
rename_old_settings() {
  local pair old new
  for pair in MACHINE_URL:RUNNER_URL MACHINE_NAMING:RUNNER_NAMING MACHINE_LOCAL_PORT:RUNNER_LOCAL_PORT \
    MACHINE_IMAGES:RUNNER_IMAGES MACHINE_TAG:RUNNER_TAG APPS_DOMAIN:ARTIFACTS_DOMAIN OPERATORS_MACHINE:OPERATORS_RUNNER \
    OTEL_WORKER_ENDPOINT:OTEL_SANDBOX_ENDPOINT WORKER_TOOL_PACKS:SANDBOX_TOOL_PACKS HOST_AGENT_IMAGE:RUNNER_AGENT_IMAGE \
    WORKER_IMAGE:SANDBOX_IMAGE AUTO_UPDATE_HOSTS:AUTO_UPDATE_RUNNERS WORKERS_MCP_URL:SANDBOXES_MCP_URL \
    WORKER_GRACE_MS:SANDBOX_GRACE_MS TAG_WORKERS:TAG_SANDBOXES WORKERS_HOST_PORT:SANDBOXES_HOST_PORT; do
    old="${pair%%:*}"; new="${pair#*:}"
    grep -q "^$old=." "$ENV_FILE" && ! grep -q "^$new=." "$ENV_FILE" || continue
    # Any empty line under the new name goes, so the file says it once.
    ( umask 077; OLD="$old" NEW_NAME="$new" awk 'BEGIN { FS = "=" } $0 == ENVIRON["NEW_NAME"] "=" { next } $1 == ENVIRON["OLD"] { $0 = ENVIRON["NEW_NAME"] substr($0, length(ENVIRON["OLD"]) + 1) } { print }' \
      "$ENV_FILE" > "$ENV_FILE.tmp" ) && cat "$ENV_FILE.tmp" > "$ENV_FILE" && rm -f "$ENV_FILE.tmp"
    _keys_said "$old is $new now"
  done
}

ec_key() { openssl ecparam -name prime256v1 -genkey -noout 2>/dev/null | openssl pkcs8 -topk8 -nocrypt 2>/dev/null | base64 | tr -d '\n'; }

# Per-service signing keys and session secrets. Each service signs as itself; a
# leaked key lets an attacker sign only as that one service, to the services
# that trust it.
ensure_service_keys() {
  for svc in CHANNEL_GATEWAY MCP_GATEWAY AGENTS TASKS RUNTIME SESSIONS TENANTS WORKERS; do ensure_env "SIGNING_KEY_$svc" "$(ec_key)"; done
  # One secret per provider (intent afe0ae46), in place of ADMIN_SECRET, which opens every control-plane admin route:
  # a leaked one opens that provider's admin API, and of the control plane's only its own callback routes. Filled
  # where the file has none or an empty one, as at every deploy, install and provision, before compose reads the file:
  # compose gives no provider the admin secret in place of its own (intent d0218d38), and stops, naming it, where one
  # is unset.
  for secret in INTENTS_SECRET INCIDENTS_SECRET IMPACT_SECRET PRIMITIVES_SECRET TASKS_SECRET AGENTS_REGISTRY_SECRET MCP_GATEWAY_SECRET; do
    fill_env "$secret" "$(openssl rand -hex 32)"
  done
  # What the tasks service seals the token each task fires with by (intent afe0ae46, phase 3): a key of its own, as
  # CREDENTIALS_KEY is the core's. Until a deploy or install makes it, the service keeps no tokens.
  fill_env TASKS_CREDENTIALS_KEY "$(openssl rand -base64 32 | tr -d '\n')"
  # The MCP gateway seals its servers' secrets with its own key (intent 4bedc187), never the core's.
  fill_env MCP_GATEWAY_CREDENTIALS_KEY "$(openssl rand -base64 32 | tr -d '\n')"
  # Nothing reads it now that n8n has left, but compose still requires it: a fresh file must not fail the deploy.
  ensure_env N8N_SIGNING_SECRET "$(openssl rand -hex 24)"
  ensure_env CONSOLE_SESSION_SECRET "$(openssl rand -base64 36 | tr -d '\n')"
}

# What a person used to choose by hand for a new box. Generated only where the
# file has nothing; hex where the value ends up inside a URL (the database's).
ensure_first_boot_secrets() {
  fill_env POSTGRES_PASSWORD "$(openssl rand -hex 24)"
  fill_env ADMIN_SECRET "$(openssl rand -hex 32)"
  fill_env CREDENTIALS_KEY "$(openssl rand -base64 32 | tr -d '\n')"
  fill_env CONSOLE_PASSWORD "$(openssl rand -hex 16)"
  fill_env REGISTRY_PASSWORD "$(openssl rand -hex 24)"
}

# A value derived from others, written over whatever is there: it follows them.
set_derived() {
  if grep -q "^$1=" "$ENV_FILE"; then
    [ "$(sed -n "s/^$1=//p" "$ENV_FILE" | tail -1)" = "$2" ] && return 0
    ( umask 077; KEY="$1" VALUE="$2" awk 'BEGIN { FS = "=" } $1 == ENVIRON["KEY"] { print ENVIRON["KEY"] "=" ENVIRON["VALUE"]; next } { print }' \
      "$ENV_FILE" > "$ENV_FILE.tmp" ) && cat "$ENV_FILE.tmp" > "$ENV_FILE" && rm -f "$ENV_FILE.tmp"
  else
    printf '%s=%s\n' "$1" "$2" >> "$ENV_FILE"
  fi
}
_env_value() { sed -n "s/^$1=//p" "$ENV_FILE" | tail -1; }

# Rauthy's own secrets: its cache's, its encryption key, its admin, and the API
# key the console uses (64 characters, as Rauthy wants).
ensure_idp_keys() {
  ensure_env IDP_SECRET_RAFT "$(openssl rand -hex 32)"
  ensure_env IDP_SECRET_API "$(openssl rand -hex 32)"
  ensure_env IDP_ENC_KEY_ID "$(openssl rand -hex 8)"
  ensure_env IDP_ENC_KEY "$(openssl rand -base64 32 | tr -d '\n')"
  ensure_env IDP_ADMIN_PASSWORD "$(openssl rand -hex 16)"
  ensure_env IDP_API_KEY_SECRET "$(openssl rand -hex 32)"
}

# Where the instance's sign-in (Rauthy) is, for the services that use it,
# written each run so it follows a change of address. Names only are printed.
#
# Rauthy is the only sign-in. An env file from before says SIGN_IN=keycloak, or
# nothing (an instance installed before Rauthy): it is on Rauthy all the same,
# its people brought from what Keycloak left in its database at Rauthy's first
# start (idp-init). SIGN_IN=rauthy is written for a release from before this
# one, installed over it again: that one reads it, and stays on Rauthy rather
# than going back to a Keycloak nobody has signed in to since.
sign_in_settings() {
  local public host
  public=$(_env_value PUBLIC_URL); public=${public%/}
  host=${public#*://}; host=${host%%/*}
  set_derived SIGN_IN rauthy
  set_derived SIGN_IN_ISSUER "$public/auth/v1/"
  set_derived SIGN_IN_INTERNAL_URL "http://idp:8080/auth/v1"
  set_derived SIGN_IN_MCP_ISSUER "$public/auth/v1/"
  set_derived SIGN_IN_MCP_JWKS "http://idp:8080/auth/v1/oidc/certs"
  # Rauthy's own view of where it is: the host people reach, and whether nginx in front speaks https for it.
  set_derived IDP_PUB_URL "$host"
  set_derived IDP_RP_ID "${host%%:*}"
  # Its passkeys' origin, which Rauthy refuses to start without a port in:
  # https://agents.example.com has none, so the scheme's own is written out.
  case "$host" in
    *:*) set_derived IDP_RP_ORIGIN "${public%%://*}://$host" ;;
    *) set_derived IDP_RP_ORIGIN "${public%%://*}://$host:$([ "${public%%://*}" = https ] && echo 443 || echo 80)" ;;
  esac
  case "$public" in
    https://*) set_derived IDP_PROXY_MODE true; set_derived IDP_COOKIE_MODE host ;;
    *) set_derived IDP_PROXY_MODE false; set_derived IDP_COOKIE_MODE danger-insecure ;;
  esac
  _keys_said "sign-in: Rauthy"
}
