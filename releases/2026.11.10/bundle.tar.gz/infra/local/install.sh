#!/usr/bin/env bash
# A control plane on this computer, reachable only from it: installs one, or
# brings one already here up to this checkout. Safe to run again: it keeps
# every value it finds in the instance's env file.
#
#   ./infra/local/install.sh                  # the instance called "local"
#   ./infra/local/install.sh control-plane conversations   # with these modules
#   INSTANCE=other ./infra/local/install.sh   # another, beside it
#   ./infra/local/install.sh --stop           # stopped; its data kept
#   ./infra/local/install.sh --voice-add parakeet      # a voice server installed (or --voice-remove)
#
# Modules: what the instance is made of. `core` (sign-in, organisations,
# projects, the console) is always there; beside it `control-plane` (runners,
# sandboxes, artifacts, intents, incidents), `conversations` (agents, channels,
# threads, WhatsApp) and `voice` (talking to sandboxes and hearing them, and
# /voice/v1 for other apps on this computer; intents cca02215, 4fe0614c).
# Named here, it has exactly those; named nowhere, it keeps
# what it has — a new instance the control plane alone, one from before modules
# all of them. A module left out stops; its data is kept, and naming it again
# brings it back. With the install line: curl … /install.sh | bash -s -- <modules>
#
# Voice's servers are installed one at a time, when asked, and nothing is downloaded
# for one that is not: --voice-add <server> installs one (and the voice module),
# --voice-remove <server> takes it off with what it downloaded. The console's
# Preferences → Voice lists them all, each with its line: speaches, parakeet, canary
# and kokoro-pt on the CPU; whisper-pt, ming and breeze on an NVIDIA card (driver 580
# or later; breeze 12 GB).
#
# From a release, it is what the install line runs (curl … /install.sh | bash):
# RELEASE, RELEASES_URL and IMAGES_FROM say which version, where later ones are
# announced and which registry has its images, and nothing is built. The same
# line, run again, upgrades: the env file is kept, what comes with the version
# is written over, and each service migrates its data when it starts.
#
# What it does:
#   1. the env file, ~/.control-plane/<instance>/stack.env: a free port, and
#      every secret and key generated (names printed, never values);
#   2. images: each used if it is here, pulled if a registry has it (IMAGES_FROM
#      to fetch from one), otherwise built from this checkout;
#   3. up, then checks: the front door, every service, the sign-in;
#   4. where to go: http://localhost:<port>/console, where the first person to
#      sign up becomes the instance's platform admin.
#
# Environment: INSTANCE (default local), CONTROL_PLANE_HOME (default
# ~/.control-plane), PORT (the first free one from 8800 otherwise), IMAGES_FROM,
# BUILD_PARALLEL (images built at once; default 1).
set -euo pipefail

INSTANCE="${INSTANCE:-local}"
[[ "$INSTANCE" =~ ^[a-z0-9][a-z0-9-]{0,30}$ ]] || { echo "INSTANCE is a short name: lowercase letters, digits and dashes" >&2; exit 2; }
HOME_DIR="${CONTROL_PLANE_HOME:-$HOME/.control-plane}/$INSTANCE"
export ENV_FILE="$HOME_DIR/stack.env"
# Named so that no runner's prefix (control-plane-…) takes the instance for one of its artifacts.
export COMPOSE_PROJECT_NAME="$INSTANCE-control-plane"
LOCAL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export STACK_COMPOSE="$LOCAL_DIR/compose.yml"

# shellcheck source=../stack/lib.sh
. "$LOCAL_DIR/../stack/lib.sh"
# shellcheck source=../deploy/keys.sh
. "$ROOT/infra/deploy/keys.sh"

STOP=0
WANT=()
VOICE_ADD=()
VOICE_REMOVE=()
while [ "$#" -gt 0 ]; do
  case "$1" in
    --stop) STOP=1 ;;
    -h|--help) sed -n '2,46p' "$0"; exit 0 ;;
    core|control-plane|conversations|voice) WANT+=("$1") ;;
    # One of the voice module's servers, installed or removed with what it downloaded (intent
    # 4fe0614c): the console's Preferences → Voice gives these lines.
    --voice-add|--voice-remove)
      [ -n "${2:-}" ] || die "$1 needs a server: $VOICE_SERVERS"
      printf '%s\n' $VOICE_SERVERS | grep -qx "$2" || die "$2 is not one of the voice servers: $VOICE_SERVERS"
      if [ "$1" = --voice-add ]; then VOICE_ADD+=("$2"); else VOICE_REMOVE+=("$2"); fi
      shift ;;
    *) die "unknown: $1 (the modules are core, control-plane, conversations and voice; --voice-add and --voice-remove take a voice server; --stop stops it)" ;;
  esac
  shift
done

if [ "$STOP" -eq 1 ]; then
  [ -f "$ENV_FILE" ] || die "no instance $INSTANCE here ($ENV_FILE)"
  # Compose reads every provider's own secret, and none is given another in its place (intent d0218d38): an env
  # file from before they were made gets them first, or compose would refuse it.
  ensure_service_keys >/dev/null
  dc stop
  ok "$INSTANCE stopped; its data is kept. Run this again to start it."
  exit 0
fi
STARTED=$(date +%s)

step "this computer"
docker version --format '{{.Server.Version}}' >/dev/null 2>&1 || die "cannot reach Docker: is Docker Desktop running?"
ok "Docker $(docker version --format '{{.Server.Version}}') ($(docker info --format '{{.OperatingSystem}}' 2>/dev/null))"
COMPOSE_VERSION=$(docker compose version --short 2>/dev/null | sed 's/^v//') || die "needs the docker compose plugin"
major=${COMPOSE_VERSION%%.*}; rest=${COMPOSE_VERSION#*.}; minor=${rest%%.*}
if [ "$major" -lt 2 ] || { [ "$major" -eq 2 ] && [ "$minor" -lt 24 ]; }; then
  die "docker compose $COMPOSE_VERSION is too old: 2.24 or later reads this stack"
fi
ok "compose $COMPOSE_VERSION"

# A value the install line decides, written over the one there.
set_env() {
  ( umask 077; KEY="$1" VALUE="$2" awk 'BEGIN { FS = "="; done = 0 } $1 == ENVIRON["KEY"] { if (!done) print ENVIRON["KEY"] "=" ENVIRON["VALUE"]; done = 1; next } { print } END { if (!done) print ENVIRON["KEY"] "=" ENVIRON["VALUE"] }' \
    "$ENV_FILE" > "$ENV_FILE.tmp" ) && cat "$ENV_FILE.tmp" > "$ENV_FILE" && rm -f "$ENV_FILE.tmp"
}

# With RUNNER_BIND, the front door also listens where Docker Engine's containers find this computer.
engine_compose() { [ -z "$(env_get RUNNER_BIND)" ] || export EXTRA_COMPOSE="$LOCAL_DIR/compose.engine.yml"; }

# Something answering on the port, on this computer.
taken() { (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null; }

step "the env file"
NEW=0
if [ ! -f "$ENV_FILE" ]; then
  # An instance whose env file is gone but whose data is still here: new secrets would
  # lock it out of its own database and sign-in (17 Oct, on Windows: the settings volume
  # was removed and the data volumes were not). Stopped, with what to do, instead.
  kept=$(docker volume ls -q --filter "label=com.docker.compose.project=$COMPOSE_PROJECT_NAME" | sort)
  if printf '%s\n' "$kept" | grep -q 'pgdata'; then
    printf '%s\n' "$kept" | sed 's/^/    /' >&2
    die "$INSTANCE already has data on this computer (above), but its env file is not at $ENV_FILE.
  That file holds the secrets its data was made with: new ones would lock the instance out of it.
  Put the file back there (with CONTROL_PLANE_HOME if it was elsewhere) and run this again.
  To start over instead, deleting that data: docker volume rm $(printf '%s ' $kept)"
  fi
  NEW=1
  mkdir -p "$HOME_DIR"
  (umask 077; cp "$LOCAL_DIR/.env.example" "$ENV_FILE")
  ok "created $ENV_FILE"
fi
# Never installed: no secrets generated yet, whoever made the file (the pipeline's
# check writes one first, naming the images it built). An instance from before
# modules always has them.
[ -n "$(env_get ADMIN_SECRET)" ] || NEW=1
chmod 600 "$ENV_FILE" 2>/dev/null || true
# Every provider's own secret, before compose reads the file for anything (an upgrade asks its Postgres below):
# compose gives none of them the admin secret in its place, and refuses a file without one (intent d0218d38).
ensure_service_keys
# The rename's window is closed (intent 683b273e): this release reads only the new names, which an instance and its
# runners move onto by running the window's last release. One installed from before goes through that first, and
# its runners connect to it once, which updates their agents; a later one is not reached from further back.
WINDOW_RELEASE=2026.10.23.3
installed=$(env_get RELEASE)
if [ "$NEW" = 0 ] && [ -n "$installed" ] && [ "$installed" != "$WINDOW_RELEASE" ] &&
  [ "$(printf '%s\n%s\n' "$installed" "$WINDOW_RELEASE" | sort -V | head -1)" = "$installed" ]; then
  die "$INSTANCE runs $installed, from before the rename's window closed (intent 683b273e).
  Install $WINDOW_RELEASE first: the same line with VERSION=$WINDOW_RELEASE. Let each of its runners connect once,
  which updates its agent, then run this again."
fi
# Settings from before the rename (intent 683b273e) take their new names, with what they say: an instance
# installed before goes on as it was. This file says the new ones from now on, and once the window closes the
# services read only those.
rename_env() {
  [ -n "$(env_get "$1")" ] && [ -z "$(env_get "$2")" ] || return 0
  ( umask 077; OLD="$1" NEW_NAME="$2" awk 'BEGIN { FS = "=" } $1 == ENVIRON["OLD"] { $0 = ENVIRON["NEW_NAME"] substr($0, length(ENVIRON["OLD"]) + 1) } { print }' \
    "$ENV_FILE" > "$ENV_FILE.tmp" ) && cat "$ENV_FILE.tmp" > "$ENV_FILE" && rm -f "$ENV_FILE.tmp"
}
for renamed in MACHINE_URL:RUNNER_URL MACHINE_BIND:RUNNER_BIND MACHINE_NAMING:RUNNER_NAMING \
  MACHINE_LOCAL_PORT:RUNNER_LOCAL_PORT MACHINE_IMAGES:RUNNER_IMAGES MACHINE_TAG:RUNNER_TAG APPS_DOMAIN:ARTIFACTS_DOMAIN \
  OPERATORS_MACHINE:OPERATORS_RUNNER OTEL_WORKER_ENDPOINT:OTEL_SANDBOX_ENDPOINT WORKER_TOOL_PACKS:SANDBOX_TOOL_PACKS \
  HOST_AGENT_IMAGE:RUNNER_AGENT_IMAGE WORKER_IMAGE:SANDBOX_IMAGE AUTO_UPDATE_HOSTS:AUTO_UPDATE_RUNNERS \
  WORKERS_MCP_URL:SANDBOXES_MCP_URL WORKER_GRACE_MS:SANDBOX_GRACE_MS TAG_WORKERS:TAG_SANDBOXES \
  WORKERS_HOST_PORT:SANDBOXES_HOST_PORT; do
  rename_env "${renamed%%:*}" "${renamed#*:}"
done
# Its modules: those named, or what it has (a new one: the control plane; one
# from before modules, which never said: every one, as it had).
if [ "${#WANT[@]}" -gt 0 ]; then
  chosen=$(printf '%s\n' "${WANT[@]}" | grep -vx core | sort -u | paste -sd, -)
  [ -n "$chosen" ] || die "core alone has nothing to run: name control-plane, conversations or both"
  set_env MODULES "$chosen"
elif [ -z "$(env_get MODULES)" ]; then
  if [ "$NEW" = 1 ]; then set_env MODULES control-plane; else set_env MODULES control-plane,conversations; fi
fi
# A voice server added brings the voice module with it.
if [ "${#VOICE_ADD[@]}" -gt 0 ] && ! has_module voice; then set_env MODULES "$(env_get MODULES),voice"; fi
ok "modules: $(modules | paste -sd' ' - | sed 's/ /, /g')"
# Runners whose agent the release about to be installed no longer answers (intent 0ea6f919): once it is in,
# nothing from the control plane reaches them, so each is updated by hand first. Told to update, an agent
# can fail to (25 Oct: a cluster's could not read the registry), and the person cannot see that from here.
# AGENT_FLOOR is the oldest release whose agent this one answers: it moves when a release stops answering
# older ones.
AGENT_FLOOR=$WINDOW_RELEASE
if [ "$NEW" = 0 ] && has_module control-plane; then
  if dc up -d --wait postgres >/dev/null 2>&1 &&
    runners=$(dc exec -T postgres psql -U agents -d workers -XAt -F $'\x1f' -c "$("$LOCAL_DIR/runners-behind.sh" --query)" 2>/dev/null); then
    # A cluster k3d made here runs kubectl inside its node's container: which ones this computer has.
    K3D_NODES=$(docker ps --format '{{.Names}}' 2>/dev/null | grep -E '^k3d-.+-server-0$' | paste -sd' ' - || true)
    if behind=$(printf '%s\n' "$runners" | K3D_NODES="$K3D_NODES" "$LOCAL_DIR/runners-behind.sh" "$AGENT_FLOOR" "$(env_get RUNNER_IMAGES)/runner-agent:$(env_get RUNNER_TAG)"); then
      ok "every runner's agent is one this release answers"
    elif [ "${UPGRADE_LEAVING_RUNNERS:-}" = 1 ]; then
      note "going on without these runners (UPGRADE_LEAVING_RUNNERS=1): this release will not reach them"
      printf '%s\n' "$behind"
    else
      printf '%s\n' "$behind" >&2
      die "these runners' agents are older than this release answers: after it, they could not connect. Update each
  as said above, see it online on the Runners page, then run this again. To go on without them:
  UPGRADE_LEAVING_RUNNERS=1 before bash on the same line."
    fi
  else
    note "could not read its runners, so they are not checked: an agent older than $AGENT_FLOOR will not connect after this"
  fi
fi
port=$(env_get HTTP_BIND | sed -n 's/.*:\([0-9][0-9]*\)$/\1/p')
if [ -z "$port" ]; then
  port="${PORT:-}"
  if [ -z "$port" ]; then
    port=8800
    while taken "$port"; do port=$((port + 1)); [ "$port" -lt 8900 ] || die "no free port between 8800 and 8899: set PORT"; done
  fi
  fill_env HTTP_BIND "127.0.0.1:$port"
fi
fill_env PUBLIC_URL "http://localhost:$port"
URL=$(env_get PUBLIC_URL)
# This computer as the instance's runner: its containers reach the front door
# through the host, its agent is named for the instance, and answers on a port
# of its own beside any other control plane's agent here (which has 7099).
fill_env RUNNER_URL "http://host.docker.internal:$port"
# Docker Engine on Linux gives containers this computer at the bridge's gateway,
# not its loopback: the front door answers there as well (compose.engine.yml).
if ! docker info --format '{{.OperatingSystem}}' 2>/dev/null | grep -qi 'docker desktop'; then
  gateway=$(docker network inspect bridge --format '{{(index .IPAM.Config 0).Gateway}}' 2>/dev/null || true)
  if [ -n "$gateway" ]; then fill_env RUNNER_BIND "$gateway:$port"; fi
fi
# Where this computer's sandboxes send their harness's telemetry: the instance's own collector,
# published on the host as the front door is, so a sandbox's container reaches it the same way.
# Without it, a project's telemetry "built in" is nowhere.
otel_port=$(env_get OTEL_BIND | sed -n 's/.*:\([0-9][0-9]*\)$/\1/p'); otel_port=${otel_port:-$(env_get OTEL_BIND)}
fill_env OTEL_SANDBOX_ENDPOINT "http://host.docker.internal:${otel_port:-4318}"
fill_env RUNNER_NAMING "control-plane-$INSTANCE"
if [ -z "$(env_get RUNNER_LOCAL_PORT)" ]; then
  agent_port=7100
  while taken "$agent_port"; do agent_port=$((agent_port + 1)); [ "$agent_port" -lt 7200 ] || die "no free port between 7100 and 7199 for the runner's agent"; done
  fill_env RUNNER_LOCAL_PORT "$agent_port"
fi
fill_env JWT_ISSUER "$URL"
fill_env MCP_AUDIENCE "$URL/mcp"
fill_env GATEWAY_AUDIENCE "$URL/gateway"
ensure_first_boot_secrets
# Sign-in: Rauthy. One installed from a release that signed people in with
# Keycloak moves to it here, its people and their passwords with it (idp-init,
# at Rauthy's first start); what Keycloak kept stays in its database.
ensure_idp_keys
sign_in_settings
# A release: its version, and where its images and the next ones are. Runners
# take theirs by the same version, and update themselves when it changes.
if [ -n "${RELEASE:-}" ]; then
  [ -n "${IMAGES_FROM:-}" ] || die "a release needs IMAGES_FROM: the registry its images are in"
  for kv in "RELEASE=$RELEASE" "RELEASES_URL=${RELEASES_URL:-}" "IMAGES_FROM=$IMAGES_FROM" "TAG=$RELEASE" \
    "EDGE_IMAGE=$IMAGES_FROM/agents/edge:$RELEASE" "RUNNER_IMAGES=$IMAGES_FROM/control-plane" "RUNNER_TAG=$RELEASE"; do
    set_env "${kv%%=*}" "${kv#*=}"
  done
  ok "release $RELEASE, from $IMAGES_FROM"
fi
# The voice module (intents cca02215, 4fe0614c): the console's voice and /voice/v1 for other
# apps, and its servers, each installed only when asked (--voice-add <server>, the line the
# console's Preferences → Voice gives), so nothing is downloaded for one nobody uses (the
# owner, 27 Oct). Which are installed is VOICE_INSTALLED; the card this computer has, the
# console says which servers fit (VOICE_CARD); the line that runs this again, the console adds a
# server's flag to (VOICE_LINE). An instance from before them had Speaches alone: it keeps it.
# The card as nvidia-smi says it, in a container (where Docker hands one over): its name,
# memory and what is in use of it (MiB), driver and compute capability; nothing without one.
gpu_card() {
  docker run --rm --gpus all ubuntu:24.04 nvidia-smi \
    --query-gpu=name,memory.total,memory.used,driver_version,compute_cap --format=csv,noheader,nounits 2>/dev/null |
    head -1 | tr -d '\r'
}
# The card the voice servers can use, as `name|MiB|in use|driver`, or why there is none.
voice_card() {
  local arch card name total used driver cap
  arch=$(docker info --format '{{.Architecture}}' 2>/dev/null || true)
  case "$arch" in x86_64|amd64) ;; *) echo "|this computer is $arch: the servers on a card are for x86"; return ;; esac
  card=$(gpu_card || true)
  [ -n "$card" ] || { echo "|no NVIDIA card that Docker hands to containers"; return; }
  IFS=, read -r name total used driver cap <<<"$card"
  name=$(echo "$name"); total=${total// /}; used=${used// /}; driver=${driver// /}; cap=${cap// /}
  if [ "${driver%%.*}" -lt 580 ] 2>/dev/null; then echo "|$name has driver $driver: the servers on a card need 580 or later (CUDA 13)"; return; fi
  if [[ "$cap" =~ ^[0-9]+\.[0-9]+$ ]] && [ $(( ${cap%.*} * 10 + ${cap#*.} )) -lt 75 ]; then
    echo "|$name is older than the 20 series"; return
  fi
  echo "$name|$total|$used|$driver"
}
# The line that runs this installer again, as it was run: what the console adds a server to.
voice_line() {
  local who=""
  [ "$INSTANCE" = local ] || who="INSTANCE=$INSTANCE "
  if [ -n "${RELEASE:-}" ] && [ -n "${RELEASES_URL:-}" ]; then
    printf 'curl -fsSL %s/install.sh | %sVERSION=%s bash -s --\n' "${RELEASES_URL%/releases}" "$who" "$RELEASE"
  else
    printf '%s%s/install.sh\n' "$who" "$LOCAL_DIR"
  fi
}
if has_module voice; then
  # Speaches, the single server before the others, stays where it was (VOICE_URL said so).
  if [ -z "$(env_get VOICE_INSTALLED)" ] && [ "$(env_get VOICE_URL)" = http://voice:8000 ]; then set_env VOICE_INSTALLED speaches; fi
  installed=$( { voice_installed; printf '%s\n' ${VOICE_ADD[@]+"${VOICE_ADD[@]}"}; } | grep -vxF -f <(printf '%s\n' ${VOICE_REMOVE[@]+"${VOICE_REMOVE[@]}"} '') | awk 'NF && !seen[$0]++' | paste -sd, -)
  IFS='|' read -r card_name card_mib card_used card_driver <<<"$(voice_card)"
  if [ -n "$card_name" ] && [ -n "$card_mib" ]; then
    set_env VOICE_CARD "$card_name"; set_env VOICE_CARD_MIB "$card_mib"
    ok "voice: $card_name, $card_mib MiB ($card_used in use now), driver $card_driver"
  else
    set_env VOICE_CARD ''; set_env VOICE_CARD_MIB ''
    note "voice: no card for its servers to use ($card_mib), so only those on the CPU can be installed"
  fi
  # A server on the card asked for where there is no card for it: said, rather than a container
  # that cannot start.
  for s in ${VOICE_ADD[@]+"${VOICE_ADD[@]}"}; do
    case "$s" in
      whisper-pt|ming) need=6000 ;;
      breeze) need=11500 ;;
      *) continue ;;
    esac
    [ -n "$card_name" ] || die "$s runs on an NVIDIA card, and $card_mib"
    [ "${card_mib:-0}" -ge "$need" ] || die "$s needs a card of $(( (need + 999) / 1000 )) GB, and $card_name has $(( card_mib / 1000 )) GB"
  done
  set_env VOICE_INSTALLED "$installed"
  set_env VOICE_URL ''; set_env VOICE_LINE "$(voice_line)"
  # Speaches' models.
  fill_env VOICE_TRANSCRIBE_MODEL Systran/faster-whisper-small
  fill_env VOICE_TRANSCRIBE_MODEL_ENGLISH Systran/faster-whisper-base.en
  fill_env VOICE_SPEECH_MODEL speaches-ai/Kokoro-82M-v1.0-ONNX-int8
  fill_env VOICE_VOICE af_heart
  ok "voice: ${installed:-no servers yet: Preferences → Voice in the console lists them, each with the line that installs it}"
else
  set_env VOICE_URL ''; set_env VOICE_INSTALLED ''; set_env VOICE_LINE ''
fi
RELEASED=$(env_get RELEASE)
IMAGES_FROM=$(env_get IMAGES_FROM)
export IMAGES_FROM
engine_compose
dc config -q || die "compose rejects the stack with this env file (above)"
ok "$ENV_FILE is complete; project $PROJECT, port $port"
if ! dc ps -q nginx 2>/dev/null | grep -q . && taken "$port"; then
  die "something else answers on port $port: free it, or set HTTP_BIND in $ENV_FILE to another"
fi

step "images"
if [ -n "$RELEASED" ]; then
  docker pull -q "$(env_get EDGE_IMAGE)" >/dev/null || die "could not pull $(env_get EDGE_IMAGE)"
  ok "the front door pulled"
else
  # Into a file, shown if it fails, and not to /dev/null: with a terminal on
  # stderr, a recent Compose draws its progress on stdout, and stops when that
  # is not a terminal either ("provided file is not a console", on a Mac).
  build_log=$(mktemp)
  dc build nginx >"$build_log" 2>&1 || { cat "$build_log" >&2; rm -f "$build_log"; die "could not build the front door"; }
  rm -f "$build_log"
  ok "the front door built"
fi
dc pull --ignore-buildable --quiet postgres otel-collector db-init >/dev/null
ok "postgres and the collector pulled"
if has_module voice; then
  # Its tier's servers made by others, each used if it is here (VOICE_IMAGE may name one built
  # here), pulled otherwise; ours (Portuguese speech) is a platform image, below.
  for svc in $(voice_services | cut -d: -f1); do
    image=$(dc config --images "$svc" 2>/dev/null | head -1)
    case "$image" in localhost:5000/agents/*) continue ;; esac
    if ! docker image inspect "$image" >/dev/null 2>&1; then
      note "$svc's image, once: ${image%%@*}"
      docker pull -q "$image" >/dev/null || die "could not pull $svc's image ($image)"
    fi
  done
  ok "the voice servers' images are here"
fi
platform_images
ok "every platform image is here (tag $(env_get TAG))"
# What this computer runs as the instance's runner: the agent and the sandbox
# image, under the names the instance tells runners (since the rename, intent
# 683b273e, runner-agent and sandbox); from a checkout, built here when they are
# not anywhere.
RUNNER_IMAGES=$(env_get RUNNER_IMAGES)
RUNNER_TAG=$(env_get RUNNER_TAG); RUNNER_TAG=${RUNNER_TAG:-latest}
for entry in runner-agent:Dockerfile.rust sandbox:sandbox/Dockerfile; do
  name="${entry%%:*}"
  image="$RUNNER_IMAGES/$name:$RUNNER_TAG"
  if docker image inspect "$image" >/dev/null 2>&1 || docker pull -q "$image" >/dev/null 2>&1; then continue; fi
  [ -z "$RELEASED" ] || die "could not pull $image"
  note "building $image from this checkout"
  # The agent is one target of the Rust Dockerfile.
  how=()
  [ "$name" != runner-agent ] || how=(--target runner-agent --build-arg SERVICE=runner-agent --build-arg BINARY=control-plane-runner)
  docker build -q -f "$ROOT/${entry#*:}" ${how[@]+"${how[@]}"} -t "$image" "$ROOT" >/dev/null || die "could not build $image"
done
ok "the runner's images are here ($RUNNER_IMAGES, $RUNNER_TAG)"

step "starting it"
# Volumes and containers first, so the collector's configuration can go into
# its volume before it starts.
dc up --no-start --remove-orphans >/dev/null 2>&1 || dc up --no-start --remove-orphans
COLLECTOR=$("$ROOT/infra/deploy/otel/place.sh" "$(volume_name agents-telemetry)" "$ENV_FILE") || die "could not place the collector's configuration"
dc up -d --remove-orphans
if [ "$COLLECTOR" = changed ]; then dc restart otel-collector >/dev/null; fi
# A module left out: compose leaves a profile's containers be, so they are
# stopped and taken off here. Their data stays in the database, for when the
# module is named again. So are voice's servers of a tier this computer is no
# longer (a card added or taken out, VOICE_SERVERS). (Keycloak's container, on an
# instance that had it, is no service of the stack's any more: `up --remove-orphans`
# took it off above, and its database stays.)
for m in control-plane conversations voice; do
  has_module "$m" && [ "$m" != voice ] && continue
  every=(); for p in $(module_all_profiles "$m"); do every+=(--profile "$p"); done
  off=$(comm -13 <(dc config --services | sort) <(dc "${every[@]}" config --services | sort))
  # Said only where it had something running: a new instance never had it.
  if [ -n "$off" ] && [ -n "$(dc "${every[@]}" ps -q $off 2>/dev/null)" ]; then
    dc "${every[@]}" rm -sf $off >/dev/null 2>&1 || true
    if [ "$m" = voice ] && has_module voice; then note "voice: stopped $(echo $off), no longer installed"
    else note "$m is not used here: stopped what it had (its data, and the voice models, are kept)"; fi
  fi
done
# A voice server removed goes with what it downloaded; installed again, it downloads it again.
for s in ${VOICE_REMOVE[@]+"${VOICE_REMOVE[@]}"}; do
  vol=voice-$s; [ "$s" != speaches ] || vol=voice-models
  kept=$(docker volume ls -q --filter "label=com.docker.compose.project=$PROJECT" --filter "label=com.docker.compose.volume=$vol")
  if [ -n "$kept" ]; then docker volume rm "$kept" >/dev/null || die "could not remove $kept: docker volume rm $kept"; fi
  ok "voice: $s removed, with what it downloaded"
done
UP_AT=$(date +%s)

step "checking it"
NET=$(network_name)
# The front door's answer at a path: from this computer, as a person's browser asks it;
# where that is not this computer (the installer run in a container, as on Windows with
# no bash), from inside the instance's network, by the front door's own name and the
# address's host. Before, such an install stopped here with the instance up, and the
# voice module's models were never downloaded.
door() {
  local code
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$URL$1" || true)
  [ "$code" = 200 ] || code=$(http_code -H "Host: ${URL#*://}" "http://nginx$1")
  echo "${code:-000}"
}
READY=0
for _ in $(seq 1 90); do
  # The front door's own answer: every module's routes are behind it, and none is always there.
  [ "$(door /edge-health)" = 200 ] && { READY=1; break; }
  sleep 2
done
[ "$READY" -eq 1 ] || { dc ps; die "$URL/edge-health did not answer within 180s"; }
ok "$URL answers ($(( $(date +%s) - UP_AT ))s after up)"
FAILED=0
for target in $(module_services); do
  code=000
  for _ in $(seq 1 30); do
    code=$(http_code "http://$target/health"); [ "$code" = 200 ] && break; sleep 2
  done
  if [ "$code" = 200 ]; then ok "$target"; else printf '  \033[31m✗\033[0m %s answered %s\n' "$target" "$code"; FAILED=1; fi
done
# Where Rauthy publishes itself.
DISCOVERY=/auth/v1/.well-known/openid-configuration
code=000
for _ in $(seq 1 60); do
  code=$(door "$DISCOVERY")
  [ "$code" = 200 ] && break; sleep 3
done
if [ "$code" = 200 ]; then ok "sign-in (Rauthy)"; else printf '  \033[31m✗\033[0m sign-in answered %s\n' "$code"; FAILED=1; fi
BAD=$(dc ps -a --format '{{.Service}} {{.State}} {{.Status}}' | grep -Ev '^(db-init|idp-init) exited .*Exited \(0\)' | grep -v ' running ' || true)
[ -z "$BAD" ] || { printf '%s\n' "$BAD" >&2; FAILED=1; }
[ "$FAILED" -eq 0 ] || die "it is up but not well (above): docker logs $PROJECT-<service>-1"

# The voice module's servers download their models as they first start (once; each keeps
# them in its volume): waited for here, each with the time it took, so the first thing said
# does not wait minutes for them. Then each language is spoken, and heard back where something
# hears it, once, as voice mode will, with the times.
voice_round_trip() {
  local lang="$1" speak="$2" model="$3" voice="$4" hear="$5" heard_model="$6" text="$7" said
  said=$(on_net --entrypoint sh curlimages/curl:latest -c '
    curl -sf -o /tmp/said.wav -w "%{time_total}" -X POST "$1/v1/audio/speech" -H "content-type: application/json" \
      -d "{\"model\":\"$2\",\"voice\":\"$3\",\"input\":\"$7\",\"response_format\":\"wav\"}" || { echo failed; exit 0; }
    [ -n "$4" ] || exit 0
    printf "|"
    curl -sf -w "|%{time_total}" -F file=@/tmp/said.wav -F model="$5" -F language="$6" "$4/v1/audio/transcriptions" || echo "|failed"
  ' sh "$speak" "$model" "$voice" "$hear" "$heard_model" "${lang%%-*}" "$text" 2>/dev/null || true)
  local spoke_in="${said%%|*}" rest="${said#*|}" heard heard_in
  if [ -z "$said" ] || [ "$spoke_in" = failed ] || [ "${rest##*|}" = failed ]; then
    note "$lang: \"$text\" was not spoken and heard back (${said:-no answer}): docker logs $PROJECT-<server>-1"
  elif [ -z "$hear" ]; then
    ok "$lang: \"$text\" spoken in ${spoke_in}s (nothing installed hears it)"
  else
    heard=$(printf '%s' "${rest%|*}" | sed -n 's/.*"text": *"\([^"]*\)".*/\1/p'); heard_in="${rest##*|}"
    ok "$lang: \"$text\" spoken in ${spoke_in}s, heard back as \"$heard\" in ${heard_in}s"
  fi
}
# The first of these servers that is installed, as `url model voice` for speaking or `url model`
# for hearing; nothing where none is.
first_of() {
  local s
  for s in "$@"; do
    voice_installed | grep -qx "${s%%=*}" && { printf '%s\n' "${s#*=}"; return; }
  done
}
if has_module voice && [ -n "$(env_get VOICE_INSTALLED)" ]; then
  step "voice"
  for target in $(voice_services); do
    svc=${target%%:*}; since=$(date +%s); code=000
    # Up to 40 minutes: the largest download is Breeze's, 6.7 GB with its image.
    for _ in $(seq 1 480); do
      code=$(http_code "http://$target/health"); [ "$code" = 200 ] && break
      [ "$(docker inspect -f '{{.RestartCount}}' "$PROJECT-$svc-1" 2>/dev/null || echo 0)" -lt 3 ] || break
      sleep 5
    done
    [ "$code" = 200 ] || die "$svc is not ready ($code): docker logs $PROJECT-$svc-1"
    ok "$svc ready ($(( $(date +%s) - since ))s)"
  done
  # Speaches' models, downloaded by asking it: it hears every language and speaks English.
  kokoro="$(env_get VOICE_SPEECH_MODEL)"
  if voice_installed | grep -qx speaches; then
    for model in "$(env_get VOICE_TRANSCRIBE_MODEL_ENGLISH)" "$(env_get VOICE_TRANSCRIBE_MODEL)" "$kokoro"; do
      [ -n "$model" ] || continue
      code=$(on_net curlimages/curl:latest -s -o /dev/null -w '%{http_code}' --max-time 1800 -X POST "http://voice:8000/v1/models/$model" 2>/dev/null || true)
      case "$code" in
        200) ok "$model downloaded" ;;
        201) ok "$model, already here" ;;
        *) die "the speech server could not download $model ($code): docker logs $PROJECT-voice-1" ;;
      esac
    done
  fi
  # Each language with what is installed for it, best first (voice_servers.rs says the same).
  read -r speak model voice <<<"$(first_of "ming=http://voice-ming:8080 ming US_Emma" "breeze=http://voice-breeze:8080 breeze warm" "speaches=http://voice:8000 $kokoro af_heart")"
  read -r hear heard_model <<<"$(first_of "parakeet=http://voice-parakeet:8080 parakeet-v2" "speaches=http://voice:8000 $(env_get VOICE_TRANSCRIBE_MODEL_ENGLISH)")"
  [ -z "${speak:-}" ] || voice_round_trip en "$speak" "$model" "$voice" "${hear:-}" "${heard_model:-}" "Voice is ready."
  read -r speak model voice <<<"$(first_of "kokoro-pt=http://voice-kokoro-pt:8000 tts-eu-pt pt-PT")"
  read -r hear heard_model <<<"$(first_of "whisper-pt=http://voice-whisper-pt:8080 whisperlv3-ft-pt" "canary=http://voice-canary:8080 canary" "speaches=http://voice:8000 $(env_get VOICE_TRANSCRIBE_MODEL)")"
  [ -z "${speak:-}" ] || voice_round_trip pt-PT "$speak" "$model" "$voice" "${hear:-}" "${heard_model:-}" "A voz está pronta."
  # What voice holds of the card, its servers loaded: what a game beside it has left.
  if voice_installed | grep -qxE 'whisper-pt|ming|breeze'; then
    IFS=, read -r name total used _ <<<"$(gpu_card || true)"
    [ -z "${total:-}" ] || ok "the card ($(echo "$name")): ${used// /} of ${total// /} MiB in use now"
  fi
fi

step "done"
printf '  open       %s/console\n' "$URL"
printf '             the first person to sign up there is this instance'"'"'s platform admin;\n'
printf '             Runners → Add a runner gives the line that makes this computer its runner\n'
[ -z "$RELEASED" ] || printf '  version    %s\n' "$RELEASED"
printf '  modules    %s\n' "$(modules | paste -sd' ' - | sed 's/ /, /g')"
printf '  env file   %s\n' "$ENV_FILE"
printf '  project    %s (%ss)\n' "$PROJECT" "$(( $(date +%s) - STARTED ))"
printf '  stop       %s --stop%s\n' "$0" "$( [ "$INSTANCE" = local ] || printf ' (with INSTANCE=%s)' "$INSTANCE")"
