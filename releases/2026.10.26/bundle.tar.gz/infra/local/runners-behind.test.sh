#!/usr/bin/env bash
# runners-behind.sh, played with the runners an instance can have (intent 0ea6f919). Run by verify.sh.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FLOOR=2026.10.23.3
IMAGE=ghcr.io/tecelon/control-plane/runner-agent:2026.10.23.3
US=$'\x1f'
row() { local IFS="$US"; printf '%s\n' "$*"; }
failures=0
check() {
  local what="$1" want_exit="$2" want="$3" input="$4" out code=0
  out=$(printf '%s' "$input" | "$here/runners-behind.sh" "$FLOOR" "$IMAGE") || code=$?
  if [ "$code" != "$want_exit" ] || [ "$out" != "$want" ]; then
    printf 'FAIL %s\n  exit %s, wanted %s\n  got:\n%s\n  wanted:\n%s\n' "$what" "$code" "$want_exit" "$out" "$want" >&2
    failures=$((failures + 1))
  else
    printf 'ok   %s\n' "$what"
  fi
}

# The owner's, on 25 Oct: a cluster runner whose agent never updated from 2026.10.19.3.
check "a cluster runner from before the floor is named, with its kubectl line" 1 \
"  Cluster: its agent is 2026.10.19.3.
    On the cluster: kubectl -n control-plane set image deploy/control-plane-host agent=$IMAGE" \
  "$(row Cluster kubernetes ghcr.io/tecelon/control-plane/host-agent:2026.10.19.3 '' '')"

check "where its agent says its namespace and deployment, they are used" 1 \
"  Lab: its agent is 2026.10.23.2.
    On the cluster: kubectl -n lab set image deploy/control-plane-runner-agent agent=$IMAGE" \
  "$(row Lab kubernetes ghcr.io/tecelon/control-plane/runner-agent:2026.10.23.2 lab control-plane-runner-agent)"

check "a Docker runner behind is sent to its new connection command" 1 \
"  Desk: its agent is 2026.10.22.3.
    In the console: Runners → Desk → New connection command, then run it on that computer." \
  "$(row Desk docker ghcr.io/tecelon/control-plane/runner-agent:2026.10.22.3 '' '')"

check "an agent that does not say which it is counts as behind" 1 \
"  Old: its agent is too old to say which it is.
    In the console: Runners → Old → New connection command, then run it on that computer." \
  "$(row Old '' '' '' '')"

check "the floor itself, and later, go on" 0 "" \
  "$(row A docker x/runner-agent:2026.10.23.3 '' '')
$(row B kubernetes x/runner-agent:2026.10.24.2 ns d)
$(row C docker x/runner-agent:2026.11.01 '' '')"

check "an agent built from a checkout cannot be told apart, and goes on" 0 "" \
  "$(row Dev docker localhost:5000/control-plane/runner-agent:latest '' '')"

check "no runners go on" 0 "" ""

check "only those behind are named, among others" 1 \
"  Old: its agent is 2026.10.19.3.
    In the console: Runners → Old → New connection command, then run it on that computer." \
  "$(row New docker x/runner-agent:2026.10.24.2 '' '')
$(row Old docker x/host-agent:2026.10.19.3 '' '')"

# The installer's own query, on a Postgres where there is one (verify.sh starts one): the columns it reads are
# the runners table's, an empty field stays a field, and a runner pending or revoked is not asked about.
if [ -n "${TEST_PG_ADMIN_URL:-}" ] && command -v psql >/dev/null 2>&1; then
  db="runners_behind_$$"
  url="${TEST_PG_ADMIN_URL%/*}/$db"
  psql "$TEST_PG_ADMIN_URL" -XqAt -c "create database $db" >/dev/null
  trap 'psql "$TEST_PG_ADMIN_URL" -XqAt -c "drop database if exists $db" >/dev/null 2>&1 || true' EXIT
  psql "$url" -Xq -v ON_ERROR_STOP=1 >/dev/null <<'SQL'
create table runners (id serial primary key, name text not null, status text not null default 'pending', info jsonb);
insert into runners (name, status, info) values
  ('Cluster', 'online', '{"runtime": {"kind": "kubernetes", "capabilities": {}}, "agent_image": "ghcr.io/tecelon/control-plane/host-agent:2026.10.19.3"}'),
  ('Current', 'offline', '{"runtime": {"kind": "docker"}, "agent_image": "x/runner-agent:2026.10.24.2", "agent_namespace": null}'),
  ('Pending', 'pending', null),
  ('Revoked', 'revoked', '{"agent_image": "x/host-agent:2026.10.01"}'),
  ('Silent', 'offline', '{"agent_version": "0.1.0"}');
SQL
  rows=$(psql "$url" -XAt -F $'\x1f' -c "$("$here/runners-behind.sh" --query)")
  check "the installer's query, on Postgres" 1 \
"  Cluster: its agent is 2026.10.19.3.
    On the cluster: kubectl -n control-plane set image deploy/control-plane-host agent=$IMAGE
  Silent: its agent is too old to say which it is.
    In the console: Runners → Silent → New connection command, then run it on that computer." "$rows"
else
  echo "skip the installer's query: no TEST_PG_ADMIN_URL and psql"
fi

[ "$failures" = 0 ] || { echo "runners-behind: $failures failed" >&2; exit 1; }
