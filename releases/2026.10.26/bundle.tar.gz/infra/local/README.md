# A control plane on one computer

The platform as a box runs it, on your own computer and reachable only from it:
`http://localhost:<port>`. For trying it, building on it, or using it where a
hosted instance is not an option.

```bash
./infra/local/install.sh
```

- **Needs** Docker with compose 2.24 or later: Docker Desktop on a Mac or
  Windows, or Docker Engine on Linux.
- **Takes** a few minutes the first time on a machine that has no images: each
  service is built from this checkout, one at a time (`BUILD_PARALLEL=3` for
  more at once, where there is memory for it).
- **Gives** `http://localhost:<port>/console`, on the first free port from 8800.
  The first person to sign up becomes the instance's platform admin and owns its
  own organisation. There is nothing else in it: no demo users, no test
  projects, nobody's operators.

## Its modules

An instance is made of modules, chosen when it is installed and changed whenever
the line is run again:

| Module | What it brings | Its services |
| --- | --- | --- |
| `core`, always | sign-in, organisations, projects, people, the console | edge, Rauthy (the sign-in), tenants, console, Postgres, the collector |
| `control-plane` | runners, sandboxes, artifacts, intents, incidents, evidence, the harness | sandboxes |
| `conversations` | agents, channels, threads, agent runs, MCP servers, tasks, model connections | agents, channel-gateway, sessions, tasks, mcp-gateway, runtime |
| `voice` | talking to a sandbox and hearing it answer, from the console: the speech server the instance's voice provider is, until a platform admin chooses another | voice (Speaches, on the CPU), and its models in a volume of their own |

```bash
./infra/local/install.sh                              # a new one: core and the control plane
./infra/local/install.sh control-plane conversations  # both
./infra/local/install.sh control-plane voice          # with voice: about 2 GB more, once
curl -fsSL …/sandboxes/v1/install.sh | bash -s -- control-plane conversations   # the same, from a release
```

- **Named:** it has exactly those, and `core`. A module left out is stopped; its
  data stays in the database, and naming it again brings it back as it was.
- **Named nowhere:** it keeps what it has. An instance installed before modules
  existed has every one.
- **What needs both:** a sandbox's tools for agents and channels, notices on
  WhatsApp, sandboxes that run on a model connection, and an artifact's threads and
  runs. With one module these are simply not offered.
- **The console** shows the pages of the modules installed, and Home asks
  nothing of the others.

## Voice

Voice is in every instance's console (intent cca02215): Accounts → Voice, and a Voice
switch in a sandbox's window. Speech goes through a **provider**, one of a list there (the
intent's `providers.md`), and a platform admin chooses which one everyone uses:

- **Browser**: each browser's own speech. Chrome sends it to Google to be heard.
- **Voice module**: this instance's own speech server, where the `voice` module is installed,
  with the installer's address and models filled in.
- **Any provider added there**: a server with OpenAI's audio interface
  (`/v1/audio/transcriptions`, `/v1/audio/speech`), such as OpenAI itself or one on your own
  computer. Presets fill in each one's fields.

The `voice` module installs one beside the instance:

- [Speaches](https://github.com/speaches-ai/speaches) 0.8.3, its CPU image, pinned, for
  amd64 and arm64;
- its models, downloaded during the install (720 MB, a minute or two): Whisper `base.en`
  for English, `small` for other languages, and Kokoro for speech.

It is the provider in use until a platform admin chooses another. The models are in
the env file (`VOICE_TRANSCRIBE_MODEL`, `VOICE_TRANSCRIBE_MODEL_ENGLISH`,
`VOICE_SPEECH_MODEL`, `VOICE_VOICE`); one changed there is kept. Taken off, the module's
container stops and its models stay in their volume.

On a CPU these models write down a sentence in about 0.4 s (`base.en`) and speak one in
about 1 s, on a machine that is doing little else. They take three to four times as long on
one that is busy (the intent's `models.md`).

**A GPU.** Docker on a Mac cannot give a container the Mac's GPU, and Docker Desktop on
Windows can only through WSL2. Where you want one, run a speech server on the computer
itself, and add it as a provider (`http://host.docker.internal:<port>`): for example
Speaches, or an MLX server on a Mac. The module itself runs on the CPU only.

**Checking a provider:** `infra/voice/conformance.sh <address> [key]` speaks a sentence and
hears it back. Inside an instance's network:

```bash
docker run --rm --network local-control-plane_net -v "$PWD/infra/voice:/v" \
  --entrypoint sh curlimages/curl:latest /v/conformance.sh http://voice:8000
```

## Signing in

People sign in with Rauthy, in tens of MB where Keycloak, which it replaced, needed most of a GB. The console
makes accounts itself (email, name, password), because Rauthy's own sign-up sets a first password by email and a
laptop has none; then people sign in on Rauthy's page.

An instance installed from a release that still had Keycloak moves to Rauthy when the line is run again: its
people come across with their passwords at Rauthy's first start, and nobody resets anything. What Keycloak kept
stays in its database, untouched (decision: intent c3c0c691, `trial-sign-in.md`).

## What it runs

`compose.yml` here includes the platform exactly as a box describes it
(`../deploy/compose.remote.yml` with `../stack/platform.yml`), with
`platform.yml` saying what differs on one computer, and one front door: the
box's nginx image, on plain http, bound to `127.0.0.1`. There are no
certificates, no registry, no GitHub runner and no landing page.

## Where things are

- **Its settings and secrets:** `~/.control-plane/<instance>/stack.env`, made
  from `.env.example` the first time and kept from then on. Its values are what
  its data is encrypted and signed with: keep the file.
- **Its data:** Docker volumes of the compose project `<instance>-control-plane`.
- **Several instances:** `INSTANCE=other ./infra/local/install.sh` makes another,
  beside the first, with its own port, env file and volumes.

## This computer as its runner

Runners → Add a runner gives one line to run here. Its agent reaches the
instance as `host.docker.internal`, names what it makes `control-plane-<instance>-…`
and answers on a port of its own, so the same computer can also stay a runner
of another control plane — the one you work in — without either touching what
the other made. Its images (the runner agent and the sandbox) are built here by
`install.sh`.

## Running it

| | |
|---|---|
| Start, or bring up to this checkout | `./infra/local/install.sh` |
| Add or take off a module | `./infra/local/install.sh control-plane conversations` |
| Stop, keeping everything | `./infra/local/install.sh --stop` |
| What a service says | `docker logs local-control-plane-<service>-1` |
| Sign in as the operator | the console's "Operator sign in", with `CONSOLE_PASSWORD` from the env file |

Proven by the `A local instance` workflow (`e2e/local/check.sh`), on the box
after every rollout of a change to what it installs and on every release: it
installs one from nothing, signs its first person up, adds the computer as its
runner, publishes an artifact from a sandbox there, and installs again over it.
