#!/usr/bin/env bash
# Which of an instance's runners have an agent older than the release about to be installed still
# answers (intent 0ea6f919). Such a runner cannot connect after the upgrade, and then nothing from the
# control plane reaches it: it is updated by hand first, with the command printed for it.
#
#   runners-behind.sh <floor> <agent image> < runners
#
# Each line of runners: name, runtime kind, agent image, agent namespace, agent deployment, separated by the
# unit separator (\x1f: a tab is whitespace to `read`, and two in a row would lose an empty field), each empty
# where the agent did not say. <floor> is the oldest release whose agent is still answered; <agent image> the
# one to put on a cluster's runner by hand. Prints one block per runner behind; exits 1 when any is.
#
#   runners-behind.sh --query   # the SQL that lists them, from the sandboxes service's database
set -euo pipefail

if [ "${1:-}" = --query ]; then
  # Every runner that has ever said what it is, and is not revoked: one offline now still comes back.
  echo "select name, coalesce(info #>> '{runtime,kind}', ''), coalesce(info ->> 'agent_image', ''),
  coalesce(info ->> 'agent_namespace', ''), coalesce(info ->> 'agent_deployment', '')
  from runners where status <> 'revoked' and info is not null order by name"
  exit 0
fi
floor="$1"
image="$2"
behind=0
# A last line with no newline after it is read too.
while IFS=$'\x1f' read -r name kind agent ns deployment || [ -n "${name:-}" ]; do
  [ -n "$name" ] || continue
  if [ -n "$agent" ]; then
    tag=""
    case "$agent" in *:*) tag="${agent##*:}" ;; esac
    # A release's tag says how old it is; any other (latest, a commit) was built from a checkout, and is let be.
    [[ "$tag" =~ ^[0-9]{4}\.[0-9]{2}\.[0-9]{2}(\.[0-9]+)?$ ]] || continue
    [ "$tag" != "$floor" ] || continue
    [ "$(printf '%s\n%s\n' "$tag" "$floor" | sort -V | head -1)" = "$tag" ] || continue
    was="its agent is $tag"
  else
    # An agent too old to say what it runs is older than any floor.
    was="its agent is too old to say which it is"
  fi
  behind=1
  printf '  %s: %s.\n' "$name" "$was"
  if [ "$kind" = kubernetes ]; then
    printf '    On the cluster: kubectl -n %s set image deploy/%s agent=%s\n' \
      "${ns:-control-plane}" "${deployment:-control-plane-host}" "$image"
  else
    printf '    In the console: Runners → %s → New connection command, then run it on that computer.\n' "$name"
  fi
done
exit "$behind"
