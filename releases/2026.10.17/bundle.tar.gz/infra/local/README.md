# A control plane on one computer

The platform as a box runs it, on your own computer and reachable only from it:
`http://localhost:<port>`. For trying it, building on it, or using it where a
hosted instance is not an option.

```bash
./infra/local/install.sh
```

- **Needs** Docker with compose 2.24 or later: Docker Desktop on a Mac or
  Windows, or Docker Engine on Linux.
- **Takes** a few minutes the first time on a machine that has no images: each
  service is built from this checkout, one at a time (`BUILD_PARALLEL=3` for
  more at once, where there is memory for it).
- **Gives** `http://localhost:<port>/console`, on the first free port from 8800.
  The first person to sign up becomes the instance's platform admin and owns its
  own organisation. There is nothing else in it: no demo users, no test
  projects, nobody's operators.

## Its modules

An instance is made of modules, chosen when it is installed and changed whenever
the line is run again:

| Module | What it brings | Its services |
| --- | --- | --- |
| `core`, always | sign-in, organisations, projects, people, the console | edge, Rauthy (the sign-in), tenants, console, Postgres, the collector |
| `control-plane` | machines, workers, apps, intents, incidents, evidence, the harness | workers |
| `conversations` | agents, channels, threads, agent runs, MCP servers, tasks, model connections | agents, channel-gateway, sessions, tasks, mcp-gateway, runtime |

```bash
./infra/local/install.sh                              # a new one: core and the control plane
./infra/local/install.sh control-plane conversations  # both
curl -fsSL …/workers/v1/install.sh | bash -s -- control-plane conversations   # the same, from a release
```

- **Named:** it has exactly those, and `core`. A module left out is stopped; its
  data stays in the database, and naming it again brings it back as it was.
- **Named nowhere:** it keeps what it has. An instance installed before modules
  existed has every one.
- **What needs both:** a worker's tools for agents and channels, notices on
  WhatsApp, workers that run on a model connection, and an app's threads and
  runs. With one module these are simply not offered.
- **The console** shows the pages of the modules installed, and Home asks
  nothing of the others.

## Signing in

People sign in with Rauthy, in tens of MB where Keycloak, which it replaced, needed most of a GB. The console
makes accounts itself (email, name, password), because Rauthy's own sign-up sets a first password by email and a
laptop has none; then people sign in on Rauthy's page.

An instance installed from a release that still had Keycloak moves to Rauthy when the line is run again: its
people come across with their passwords at Rauthy's first start, and nobody resets anything. What Keycloak kept
stays in its database, untouched (decision: intent c3c0c691, `trial-sign-in.md`).

## What it runs

`compose.yml` here includes the platform exactly as a box describes it
(`../deploy/compose.remote.yml` with `../stack/platform.yml`), with
`platform.yml` saying what differs on one computer, and one front door: the
box's nginx image, on plain http, bound to `127.0.0.1`. There are no
certificates, no registry, no runners and no landing page.

## Where things are

- **Its settings and secrets:** `~/.control-plane/<instance>/stack.env`, made
  from `.env.example` the first time and kept from then on. Its values are what
  its data is encrypted and signed with: keep the file.
- **Its data:** Docker volumes of the compose project `<instance>-control-plane`.
- **Several instances:** `INSTANCE=other ./infra/local/install.sh` makes another,
  beside the first, with its own port, env file and volumes.

## This computer as its machine

Machines → Add a machine gives one line to run here. Its agent reaches the
instance as `host.docker.internal`, names what it makes `control-plane-<instance>-…`
and answers on a port of its own, so the same computer can also stay a machine
of another control plane — the one you work in — without either touching what
the other made. Its images (the agent and the worker) are built here by
`install.sh`.

## Running it

| | |
|---|---|
| Start, or bring up to this checkout | `./infra/local/install.sh` |
| Add or take off a module | `./infra/local/install.sh control-plane conversations` |
| Stop, keeping everything | `./infra/local/install.sh --stop` |
| What a service says | `docker logs local-control-plane-<service>-1` |
| Sign in as the operator | the console's "Operator sign in", with `CONSOLE_PASSWORD` from the env file |

Proven by the `A local instance` workflow (`e2e/local/check.sh`), on the box
after every rollout of a change to what it installs and on every release: it
installs one from nothing, signs its first person up, adds the computer as its
machine, publishes an app from a worker there, and installs again over it.
