#!/usr/bin/env bash
# A control plane on this computer, reachable only from it: installs one, or
# brings one already here up to this checkout. Safe to run again: it keeps
# every value it finds in the instance's env file.
#
#   ./infra/local/install.sh                  # the instance called "local"
#   ./infra/local/install.sh control-plane conversations   # with these modules
#   INSTANCE=other ./infra/local/install.sh   # another, beside it
#   ./infra/local/install.sh --stop           # stopped; its data kept
#
# Modules: what the instance is made of. `core` (sign-in, organisations,
# projects, the console) is always there; beside it `control-plane` (machines,
# workers, apps, intents, incidents) and `conversations` (agents, channels,
# threads, WhatsApp). Named here, it has exactly those; named nowhere, it keeps
# what it has — a new instance the control plane alone, one from before modules
# all of them. A module left out stops; its data is kept, and naming it again
# brings it back. With the install line: curl … /install.sh | bash -s -- <modules>
#
# From a release, it is what the install line runs (curl … /install.sh | bash):
# RELEASE, RELEASES_URL and IMAGES_FROM say which version, where later ones are
# announced and which registry has its images, and nothing is built. The same
# line, run again, upgrades: the env file is kept, what comes with the version
# is written over, and each service migrates its data when it starts.
#
# What it does:
#   1. the env file, ~/.control-plane/<instance>/stack.env: a free port, and
#      every secret and key generated (names printed, never values);
#   2. images: each used if it is here, pulled if a registry has it (IMAGES_FROM
#      to fetch from one), otherwise built from this checkout;
#   3. up, then checks: the front door, every service, the sign-in;
#   4. where to go: http://localhost:<port>/console, where the first person to
#      sign up becomes the instance's platform admin.
#
# Environment: INSTANCE (default local), CONTROL_PLANE_HOME (default
# ~/.control-plane), PORT (the first free one from 8800 otherwise), IMAGES_FROM,
# BUILD_PARALLEL (images built at once; default 1).
set -euo pipefail

INSTANCE="${INSTANCE:-local}"
[[ "$INSTANCE" =~ ^[a-z0-9][a-z0-9-]{0,30}$ ]] || { echo "INSTANCE is a short name: lowercase letters, digits and dashes" >&2; exit 2; }
HOME_DIR="${CONTROL_PLANE_HOME:-$HOME/.control-plane}/$INSTANCE"
export ENV_FILE="$HOME_DIR/stack.env"
# Named so that no machine's prefix (control-plane-…) takes the instance for one of its apps.
export COMPOSE_PROJECT_NAME="$INSTANCE-control-plane"
LOCAL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export STACK_COMPOSE="$LOCAL_DIR/compose.yml"

# shellcheck source=../stack/lib.sh
. "$LOCAL_DIR/../stack/lib.sh"
# shellcheck source=../deploy/keys.sh
. "$ROOT/infra/deploy/keys.sh"

STOP=0
WANT=()
for arg in "$@"; do
  case "$arg" in
    --stop) STOP=1 ;;
    -h|--help) sed -n '2,33p' "$0"; exit 0 ;;
    core|control-plane|conversations) WANT+=("$arg") ;;
    *) die "unknown: $arg (the modules are core, control-plane and conversations; --stop stops it)" ;;
  esac
done

if [ "$STOP" -eq 1 ]; then
  [ -f "$ENV_FILE" ] || die "no instance $INSTANCE here ($ENV_FILE)"
  dc stop
  ok "$INSTANCE stopped; its data is kept. Run this again to start it."
  exit 0
fi
STARTED=$(date +%s)

step "this computer"
docker version --format '{{.Server.Version}}' >/dev/null 2>&1 || die "cannot reach Docker: is Docker Desktop running?"
ok "Docker $(docker version --format '{{.Server.Version}}') ($(docker info --format '{{.OperatingSystem}}' 2>/dev/null))"
COMPOSE_VERSION=$(docker compose version --short 2>/dev/null | sed 's/^v//') || die "needs the docker compose plugin"
major=${COMPOSE_VERSION%%.*}; rest=${COMPOSE_VERSION#*.}; minor=${rest%%.*}
if [ "$major" -lt 2 ] || { [ "$major" -eq 2 ] && [ "$minor" -lt 24 ]; }; then
  die "docker compose $COMPOSE_VERSION is too old: 2.24 or later reads this stack"
fi
ok "compose $COMPOSE_VERSION"

# A value the install line decides, written over the one there.
set_env() {
  ( umask 077; KEY="$1" VALUE="$2" awk 'BEGIN { FS = "="; done = 0 } $1 == ENVIRON["KEY"] { if (!done) print ENVIRON["KEY"] "=" ENVIRON["VALUE"]; done = 1; next } { print } END { if (!done) print ENVIRON["KEY"] "=" ENVIRON["VALUE"] }' \
    "$ENV_FILE" > "$ENV_FILE.tmp" ) && cat "$ENV_FILE.tmp" > "$ENV_FILE" && rm -f "$ENV_FILE.tmp"
}

# With MACHINE_BIND, the front door also listens where Docker Engine's containers find this computer.
engine_compose() { [ -z "$(env_get MACHINE_BIND)" ] || export EXTRA_COMPOSE="$LOCAL_DIR/compose.engine.yml"; }

# Something answering on the port, on this computer.
taken() { (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null; }

step "the env file"
NEW=0
if [ ! -f "$ENV_FILE" ]; then
  NEW=1
  mkdir -p "$HOME_DIR"
  (umask 077; cp "$LOCAL_DIR/.env.example" "$ENV_FILE")
  ok "created $ENV_FILE"
fi
# Never installed: no secrets generated yet, whoever made the file (the pipeline's
# check writes one first, naming the images it built). An instance from before
# modules always has them.
[ -n "$(env_get ADMIN_SECRET)" ] || NEW=1
chmod 600 "$ENV_FILE" 2>/dev/null || true
# Its modules: those named, or what it has (a new one: the control plane; one
# from before modules, which never said: every one, as it had).
if [ "${#WANT[@]}" -gt 0 ]; then
  chosen=$(printf '%s\n' "${WANT[@]}" | grep -vx core | sort -u | paste -sd, -)
  [ -n "$chosen" ] || die "core alone has nothing to run: name control-plane, conversations or both"
  set_env MODULES "$chosen"
elif [ -z "$(env_get MODULES)" ]; then
  if [ "$NEW" = 1 ]; then set_env MODULES control-plane; else set_env MODULES control-plane,conversations; fi
fi
ok "modules: $(modules | paste -sd' ' - | sed 's/ /, /g')"
port=$(env_get HTTP_BIND | sed -n 's/.*:\([0-9][0-9]*\)$/\1/p')
if [ -z "$port" ]; then
  port="${PORT:-}"
  if [ -z "$port" ]; then
    port=8800
    while taken "$port"; do port=$((port + 1)); [ "$port" -lt 8900 ] || die "no free port between 8800 and 8899: set PORT"; done
  fi
  fill_env HTTP_BIND "127.0.0.1:$port"
fi
fill_env PUBLIC_URL "http://localhost:$port"
URL=$(env_get PUBLIC_URL)
# This computer as the instance's machine: its containers reach the front door
# through the host, its agent is named for the instance, and answers on a port
# of its own beside any other control plane's agent here (which has 7099).
fill_env MACHINE_URL "http://host.docker.internal:$port"
# Docker Engine on Linux gives containers this computer at the bridge's gateway,
# not its loopback: the front door answers there as well (compose.engine.yml).
if ! docker info --format '{{.OperatingSystem}}' 2>/dev/null | grep -qi 'docker desktop'; then
  gateway=$(docker network inspect bridge --format '{{(index .IPAM.Config 0).Gateway}}' 2>/dev/null || true)
  if [ -n "$gateway" ]; then fill_env MACHINE_BIND "$gateway:$port"; fi
fi
# Where this computer's workers send their harness's telemetry: the instance's own collector,
# published on the host as the front door is, so a worker's container reaches it the same way.
# Without it, a project's telemetry "built in" is nowhere.
otel_port=$(env_get OTEL_BIND | sed -n 's/.*:\([0-9][0-9]*\)$/\1/p'); otel_port=${otel_port:-$(env_get OTEL_BIND)}
fill_env OTEL_WORKER_ENDPOINT "http://host.docker.internal:${otel_port:-4318}"
fill_env MACHINE_NAMING "control-plane-$INSTANCE"
if [ -z "$(env_get MACHINE_LOCAL_PORT)" ]; then
  agent_port=7100
  while taken "$agent_port"; do agent_port=$((agent_port + 1)); [ "$agent_port" -lt 7200 ] || die "no free port between 7100 and 7199 for the machine's agent"; done
  fill_env MACHINE_LOCAL_PORT "$agent_port"
fi
fill_env JWT_ISSUER "$URL"
fill_env MCP_AUDIENCE "$URL/mcp"
fill_env GATEWAY_AUDIENCE "$URL/gateway"
ensure_first_boot_secrets
ensure_service_keys
# Sign-in: Rauthy. One installed from a release that signed people in with
# Keycloak moves to it here, its people and their passwords with it (idp-init,
# at Rauthy's first start); what Keycloak kept stays in its database.
ensure_idp_keys
sign_in_settings
# A release: its version, and where its images and the next ones are. Machines
# take theirs by the same version, and update themselves when it changes.
if [ -n "${RELEASE:-}" ]; then
  [ -n "${IMAGES_FROM:-}" ] || die "a release needs IMAGES_FROM: the registry its images are in"
  for kv in "RELEASE=$RELEASE" "RELEASES_URL=${RELEASES_URL:-}" "IMAGES_FROM=$IMAGES_FROM" "TAG=$RELEASE" \
    "EDGE_IMAGE=$IMAGES_FROM/agents/edge:$RELEASE" "MACHINE_IMAGES=$IMAGES_FROM/control-plane" "MACHINE_TAG=$RELEASE"; do
    set_env "${kv%%=*}" "${kv#*=}"
  done
  ok "release $RELEASE, from $IMAGES_FROM"
fi
RELEASED=$(env_get RELEASE)
IMAGES_FROM=$(env_get IMAGES_FROM)
export IMAGES_FROM
engine_compose
dc config -q || die "compose rejects the stack with this env file (above)"
ok "$ENV_FILE is complete; project $PROJECT, port $port"
if ! dc ps -q nginx 2>/dev/null | grep -q . && taken "$port"; then
  die "something else answers on port $port: free it, or set HTTP_BIND in $ENV_FILE to another"
fi

step "images"
if [ -n "$RELEASED" ]; then
  docker pull -q "$(env_get EDGE_IMAGE)" >/dev/null || die "could not pull $(env_get EDGE_IMAGE)"
  ok "the front door pulled"
else
  # Into a file, shown if it fails, and not to /dev/null: with a terminal on
  # stderr, a recent Compose draws its progress on stdout, and stops when that
  # is not a terminal either ("provided file is not a console", on a Mac).
  build_log=$(mktemp)
  dc build nginx >"$build_log" 2>&1 || { cat "$build_log" >&2; rm -f "$build_log"; die "could not build the front door"; }
  rm -f "$build_log"
  ok "the front door built"
fi
dc pull --ignore-buildable --quiet postgres otel-collector db-init >/dev/null
ok "postgres and the collector pulled"
platform_images
ok "every platform image is here (tag $(env_get TAG))"
# What this computer runs as the instance's machine: the agent and the worker,
# under the names the instance tells machines; from a checkout, built here when
# they are not anywhere.
MACHINE_IMAGES=$(env_get MACHINE_IMAGES)
MACHINE_TAG=$(env_get MACHINE_TAG); MACHINE_TAG=${MACHINE_TAG:-latest}
for entry in host-agent:Dockerfile.rust worker:workers/Dockerfile; do
  name="${entry%%:*}"
  image="$MACHINE_IMAGES/$name:$MACHINE_TAG"
  if docker image inspect "$image" >/dev/null 2>&1 || docker pull -q "$image" >/dev/null 2>&1; then continue; fi
  [ -z "$RELEASED" ] || die "could not pull $image"
  note "building $image from this checkout"
  # The agent is one target of the Rust Dockerfile.
  how=()
  [ "$name" != host-agent ] || how=(--target host-agent --build-arg SERVICE=host-agent --build-arg BINARY=control-plane-host)
  docker build -q -f "$ROOT/${entry#*:}" ${how[@]+"${how[@]}"} -t "$image" "$ROOT" >/dev/null || die "could not build $image"
done
ok "the machine's images are here ($MACHINE_IMAGES, $MACHINE_TAG)"

step "starting it"
# Volumes and containers first, so the collector's configuration can go into
# its volume before it starts.
dc up --no-start --remove-orphans >/dev/null 2>&1 || dc up --no-start --remove-orphans
COLLECTOR=$("$ROOT/infra/deploy/otel/place.sh" "$(volume_name agents-telemetry)" "$ENV_FILE") || die "could not place the collector's configuration"
dc up -d --remove-orphans
if [ "$COLLECTOR" = changed ]; then dc restart otel-collector >/dev/null; fi
# A module left out: compose leaves a profile's containers be, so they are
# stopped and taken off here. Their data stays in the database, for when the
# module is named again. (Keycloak's container, on an instance that had it, is
# no service of the stack's any more: `up --remove-orphans` took it off above,
# and its database stays.)
for m in control-plane conversations; do
  has_module "$m" && continue
  off=$(comm -13 <(dc config --services | sort) <(dc --profile "$m" config --services | sort))
  # Said only where it had something running: a new instance never had it.
  if [ -n "$off" ] && [ -n "$(dc --profile "$m" ps -q $off 2>/dev/null)" ]; then
    dc --profile "$m" rm -sf $off >/dev/null 2>&1 || true
    note "$m is not used here: stopped what it had (its data is kept)"
  fi
done
UP_AT=$(date +%s)

step "checking it"
NET=$(network_name)
READY=0
for _ in $(seq 1 90); do
  # The front door's own answer: every module's routes are behind it, and none is always there.
  [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$URL/edge-health" || true)" = 200 ] && { READY=1; break; }
  sleep 2
done
[ "$READY" -eq 1 ] || { dc ps; die "$URL/edge-health did not answer within 180s"; }
ok "$URL answers ($(( $(date +%s) - UP_AT ))s after up)"
FAILED=0
for target in $(module_services); do
  code=000
  for _ in $(seq 1 30); do
    code=$(http_code "http://$target/health"); [ "$code" = 200 ] && break; sleep 2
  done
  if [ "$code" = 200 ]; then ok "$target"; else printf '  \033[31m✗\033[0m %s answered %s\n' "$target" "$code"; FAILED=1; fi
done
# Where Rauthy publishes itself.
DISCOVERY=/auth/v1/.well-known/openid-configuration
code=000
for _ in $(seq 1 60); do
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$URL$DISCOVERY" || true)
  [ "$code" = 200 ] && break; sleep 3
done
if [ "$code" = 200 ]; then ok "sign-in (Rauthy)"; else printf '  \033[31m✗\033[0m sign-in answered %s\n' "$code"; FAILED=1; fi
BAD=$(dc ps -a --format '{{.Service}} {{.State}} {{.Status}}' | grep -Ev '^(db-init|idp-init) exited .*Exited \(0\)' | grep -v ' running ' || true)
[ -z "$BAD" ] || { printf '%s\n' "$BAD" >&2; FAILED=1; }
[ "$FAILED" -eq 0 ] || die "it is up but not well (above): docker logs $PROJECT-<service>-1"

step "done"
printf '  open       %s/console\n' "$URL"
printf '             the first person to sign up there is this instance'"'"'s platform admin;\n'
printf '             Machines → Add a machine gives the line that makes this computer its machine\n'
[ -z "$RELEASED" ] || printf '  version    %s\n' "$RELEASED"
printf '  modules    %s\n' "$(modules | paste -sd' ' - | sed 's/ /, /g')"
printf '  env file   %s\n' "$ENV_FILE"
printf '  project    %s (%ss)\n' "$PROJECT" "$(( $(date +%s) - STARTED ))"
printf '  stop       %s --stop%s\n' "$0" "$( [ "$INSTANCE" = local ] || printf ' (with INSTANCE=%s)' "$INSTANCE")"
