#!/usr/bin/env bash
#
# Puts the collector's configuration into its volume before the stack starts:
# The control plane's own (collector.yaml, beside this), or a deployment's, which its env
# file names. Where telemetry goes is that file's business, so pointing it at
# another store is a file beside the env file and two lines in it, never a
# change here (README.md).
#
#   OTEL_COLLECTOR_CONFIG=/var/lib/control-plane-deploy/collector.yaml   instead of the control plane's
#   OTEL_COLLECTOR_ENV=/var/lib/control-plane-deploy/collector.env       what it reads as ${env:NAME}
#
# Absolute paths, on the machine that runs the rollout: compose reads the env
# file itself, and would read a relative one against the compose file, not
# beside the env file where it belongs. The collector checks the new
# configuration before it replaces the old one, so one it cannot run stops the
# rollout here, with its reason, and the collector keeps what it had.
#
# It prints `changed` or `unchanged` and nothing else on stdout: the collector
# reads its configuration when it starts, and compose does not restart a
# container whose definition is the same, so the caller restarts it on `changed`.
#
#   place.sh <volume> <env file>     DOCKER="docker --context box" for another daemon
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VOLUME="${1:?the collector volume}"
ENV_FILE="${2:?the env file}"
read -r -a DOCKER <<<"${DOCKER:-docker}"
die() { printf 'collector: %s\n' "$*" >&2; exit 1; }
say() { printf 'collector: %s\n' "$*" >&2; }

envval() { sed -n "s/^$1=//p" "$ENV_FILE" | tail -1; }
given() {
  case "$2" in /*) ;; *) die "$1 is $2: give it as an absolute path" ;; esac
  [ -f "$2" ] || die "$1 names $2, which is not there"
  printf '%s' "$2"
}
# The image compose runs, so the check is made by the collector that will read it.
IMAGE=$(awk '/^  otel-collector:/ { on = 1; next } on && /^  [a-z]/ { exit } on && $1 == "image:" { print $2; exit }' "$HERE/../compose.remote.yml")
[ -n "$IMAGE" ] || die "no otel-collector image in compose.remote.yml"

CONFIG="$HERE/collector.yaml"
[ -z "$(envval OTEL_COLLECTOR_CONFIG)" ] || CONFIG=$(given OTEL_COLLECTOR_CONFIG "$(envval OTEL_COLLECTOR_CONFIG)")
ENVS=()
[ -z "$(envval OTEL_COLLECTOR_ENV)" ] || ENVS=(--env-file "$(given OTEL_COLLECTOR_ENV "$(envval OTEL_COLLECTOR_ENV)")")

# Owned by the collector's user (10001), or it cannot write its own records.
"${DOCKER[@]}" run --rm -i -v "$VOLUME:/records" alpine:3 sh -c 'cat > /records/collector.next.yaml && chown -R 10001:10001 /records' <"$CONFIG" ||
  die "could not write to $VOLUME"
if ! "${DOCKER[@]}" run --rm -v "$VOLUME:/records" ${ENVS[@]+"${ENVS[@]}"} "$IMAGE" validate --config=/records/collector.next.yaml >&2; then
  "${DOCKER[@]}" run --rm -v "$VOLUME:/records" alpine:3 rm -f /records/collector.next.yaml >/dev/null 2>&1 || true
  die "$CONFIG is not a configuration $IMAGE can run (above); the collector keeps the one it has"
fi
WHOSE=$([ "$CONFIG" = "$HERE/collector.yaml" ] && echo "The control plane's configuration" || echo "this deployment's configuration, $CONFIG")
if "${DOCKER[@]}" run --rm -v "$VOLUME:/records" alpine:3 cmp -s /records/collector.next.yaml /records/collector.yaml; then
  "${DOCKER[@]}" run --rm -v "$VOLUME:/records" alpine:3 rm -f /records/collector.next.yaml >/dev/null || true
  say "$WHOSE, as it was"; echo unchanged
else
  "${DOCKER[@]}" run --rm -v "$VOLUME:/records" alpine:3 mv /records/collector.next.yaml /records/collector.yaml || die "could not put it in place"
  say "$WHOSE, new"; echo changed
fi
