# shellcheck shell=bash
# What provision.sh, move.sh and rehearse.sh share: how they call compose on the
# stack, and how they find what it named things. Sourced, not run.

STACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$STACK_DIR/../.." && pwd)"
PROJECT="${COMPOSE_PROJECT_NAME:-control-plane}"
ENV_FILE="${ENV_FILE:-$STACK_DIR/.env}"

ok()   { printf '  \033[32m✓\033[0m %s\n' "$1"; }
note() { printf '  \033[33m•\033[0m %s\n' "$1"; }
die()  { printf '  \033[31m✗ %s\033[0m\n' "$1" >&2; exit 1; }

STEP_AT=$(date +%s); STEP_NAME=""
step() {
  local now; now=$(date +%s)
  [ -n "$STEP_NAME" ] && printf '  \033[2m(%s took %ss)\033[0m\n' "$STEP_NAME" "$((now - STEP_AT))"
  STEP_AT=$now; STEP_NAME="$1"
  printf '\n\033[1m── %s\033[0m \033[2m[%s]\033[0m\n' "$1" "$(date -u +%H:%M:%S)"
}

# The stack's compose file (STACK_COMPOSE: ../local/compose.yml for an instance on
# one computer), and any further ones (a rehearsal's), colon-separated, merged over it.
compose_files() {
  printf -- '-f\n%s\n' "${STACK_COMPOSE:-$STACK_DIR/compose.yml}"
  local IFS=:
  for f in ${EXTRA_COMPOSE:-}; do [ -n "$f" ] && printf -- '-f\n%s\n' "$f"; done
}
# What the instance is made of (MODULES in its env file): core always, and the
# control plane, conversations or both. An env file that names none is from
# before modules, and had every service: it still has.
modules() {
  local m; m=$(env_get MODULES)
  printf '%s\n' "core" ${m:-control-plane conversations} | tr ',' '\n' | awk 'NF && !seen[$0]++'
}
has_module() { modules | grep -qx "$1"; }
# Each module beside core is a compose profile: its services start only with it.
# Passed as flags rather than COMPOSE_PROFILES, which a caller's own --profile
# would replace.
module_profiles() {
  modules | grep -vx core | while read -r m; do module_profile "$m" | while read -r p; do printf -- '--profile\n%s\n' "$p"; done; done
}
# Voice's servers are a profile each (intent 4fe0614c): those installed (VOICE_INSTALLED, which
# `--voice-add` and `--voice-remove` change), and none otherwise. The voice module itself is the
# console's, and starts nothing.
VOICE_SERVERS="speaches parakeet canary whisper-pt kokoro-pt ming breeze"
voice_installed() { env_get VOICE_INSTALLED | tr ', ' '\n\n' | awk 'NF'; }
module_profile() {
  if [ "$1" = voice ]; then voice_installed | sed 's/^/voice-/'; else printf '%s\n' "$1"; fi
}
# Every profile a module has: what is stopped when it is taken off, or when a server is removed.
module_all_profiles() {
  if [ "$1" = voice ]; then local s; for s in $VOICE_SERVERS; do printf 'voice-%s\n' "$s"; done; else printf '%s\n' "$1"; fi
}
# The services an instance answers with, by module, and where each says it is well. Voice's
# servers are not among them: they download their models as they first start, which takes
# minutes, and the installer waits for them on their own (voice_services).
module_services() {
  has_module core && printf '%s\n' console:3050 tenants:3080 tasks:3070
  has_module control-plane && printf '%s\n' sandboxes:3090 intents:3100 incidents:3110 impact:3120
  has_module conversations && printf '%s\n' channel-gateway:3030 sessions:3010 runtime:3040 conversational-agents:3060
  # The MCP gateway and the packages (intent 4bedc187) are either module's, and started with whichever is here: a
  # conversational agent's MCP servers are its packages' picks.
  { has_module control-plane || has_module conversations; } && printf '%s\n' mcp-gateway:3020 primitives:3130
  return 0
}
# Voice's servers installed here, and where each says it is well: compose's own list of what
# their profiles start, so the two cannot disagree.
voice_services() {
  has_module voice || return 0
  local s
  for s in $(dc config --services 2>/dev/null); do
    case "$s" in
      voice) printf '%s\n' voice:8000 ;;
      voice-kokoro-pt) printf '%s\n' voice-kokoro-pt:8000 ;;
      voice-*) printf '%s:8080\n' "$s" ;;
    esac
  done
}

dc() {
  local args=()
  while IFS= read -r a; do args+=("$a"); done < <(compose_files)
  while IFS= read -r a; do args+=("$a"); done < <(module_profiles)
  docker compose -p "$PROJECT" --env-file "$ENV_FILE" "${args[@]}" "$@"
}

# A value from the env file, without sourcing it (it is not shell, and sourcing
# would put every secret in this shell's environment).
env_get() { grep -E "^$1=" "$ENV_FILE" 2>/dev/null | tail -1 | cut -d= -f2- || true; }

# The name compose gave a volume or network, read from its own rendering of the
# stack, so these scripts can never disagree with compose.yml about it.
resource_name() {
  local kind="$1" key="$2"
  dc config 2>/dev/null | awk -v kind="$kind:" -v key="  $key:" '
    /^[a-z]/ { top = $1 }
    top == kind && $0 == key { inside = 1; next }
    top == kind && inside && /^    name: / { sub(/^    name: /, ""); print; exit }
    top == kind && /^  [^ ]/ { inside = 0 }'
}
volume_name()  { resource_name volumes "$1"; }
network_name() { resource_name networks agents-net; }

# A one-off container on the stack's network: how these scripts reach the
# services by name, the same way on a Linux machine and on Docker Desktop.
on_net() { docker run --rm --network "${NET:=$(network_name)}" "$@"; }
http_code() {
  local code
  code=$(on_net curlimages/curl:latest -s -o /dev/null -w '%{http_code}' --max-time 10 "$@" 2>/dev/null) || true
  echo "${code:-000}"
}

# Every platform image the stack runs, on this machine: used if it is here,
# pulled if its registry has it, pulled from IMAGES_FROM and retagged if that is
# set, and otherwise built from this checkout, one at a time (a machine building
# eleven Node services at once runs out of memory before it runs out of cores).
# A release has no sources to build from: one it cannot pull is named, and why that
# may be (27 Oct: the voice module's first image of ours was published private).
platform_images() {
  local to_build=() svc image
  while read -r svc image; do
    case "$image" in localhost:5000/agents/*) ;; *) continue ;; esac
    if docker image inspect "$image" >/dev/null 2>&1; then continue; fi
    if docker pull -q "$image" >/dev/null 2>&1; then ok "pulled $image"; continue; fi
    if [ -n "${IMAGES_FROM:-}" ] && docker pull -q "$IMAGES_FROM/${image#localhost:5000/}" >/dev/null 2>&1; then
      docker tag "$IMAGES_FROM/${image#localhost:5000/}" "$image"
      ok "pulled $image from $IMAGES_FROM"; continue
    fi
    [ -z "$(env_get RELEASE)" ] ||
      die "could not pull ${IMAGES_FROM:-its registry}/${image#localhost:5000/} for $svc: an image new in this release may not be public yet"
    to_build+=("$svc")
  done < <(dc config | awk '/^[a-z]/ { top = $1 }
    top == "services:" && /^  [a-z0-9-]+:$/ { svc = $1; sub(":", "", svc) }
    top == "services:" && /^    image: / { print svc, $2 }')
  if [ "${#to_build[@]}" -gt 0 ]; then
    note "not in any registry, so built from this checkout: ${to_build[*]}"
    COMPOSE_PARALLEL_LIMIT="${BUILD_PARALLEL:-1}" dc build "${to_build[@]}"
  fi
}
