# A control plane on one computer

The platform as a box runs it, on your own computer and reachable only from it:
`http://localhost:<port>`. For trying it, building on it, or using it where a
hosted instance is not an option.

```bash
./infra/local/install.sh
```

- **Needs** Docker with compose 2.24 or later: Docker Desktop on a Mac or
  Windows, or Docker Engine on Linux.
- **Takes** a few minutes the first time on a machine that has no images: each
  service is built from this checkout, one at a time (`BUILD_PARALLEL=3` for
  more at once, where there is memory for it).
- **Gives** `http://localhost:<port>/console`, on the first free port from 8800.
  The first person to sign up becomes the instance's platform admin and owns its
  own organisation. There is nothing else in it: no demo users, no test
  projects, nobody's operators.

## Its modules

An instance is made of modules, chosen when it is installed and changed whenever
the line is run again:

| Module | What it brings | Its services |
| --- | --- | --- |
| `core`, always | sign-in, organisations, projects, people, the console | edge, Rauthy (the sign-in), tenants, console, Postgres, the collector |
| `control-plane` | runners, sandboxes, artifacts, intents, incidents, evidence, the harness | sandboxes, intents (the backlog), incidents, impact, primitives (packages) |
| `conversations` | agents, channels, threads, agent runs, MCP servers, tasks, model connections | agents, channel-gateway, sessions, tasks, mcp-gateway, runtime |
| `voice` | talking to a sandbox and hearing it answer, from the console, and `/voice/v1` for other apps on this computer | none of its own: its speech servers are installed one at a time (below) |

```bash
./infra/local/install.sh                              # a new one: core and the control plane
./infra/local/install.sh control-plane conversations  # both
./infra/local/install.sh control-plane voice          # with voice, and no speech server yet
./infra/local/install.sh --voice-add parakeet         # a speech server installed (below)
curl -fsSL …/sandboxes/v1/install.sh | bash -s -- control-plane conversations   # the same, from a release
```

- **Named:** it has exactly those, and `core`. A module left out is stopped; its
  data stays in the database, and naming it again brings it back as it was.
- **Named nowhere:** it keeps what it has. An instance installed before modules
  existed has every one.
- **What needs both:** a sandbox's tools for agents and channels, notices on
  WhatsApp, sandboxes that run on a model connection, and an artifact's threads and
  runs. With one module these are simply not offered.
- **The console** shows the pages of the modules installed, and Home asks
  nothing of the others.

## Voice

Voice is in every instance's console (intent cca02215): Preferences → Voice, and a Voice
switch in a sandbox's window. Speech goes through **providers**, a list there (the intent's
`providers.md`), each one a connection:

- **Browser**: each browser's own speech. Chrome sends it to Google to be heard.
- **The voice module's servers**, where the `voice` module is installed: every one is on the
  list, installed or not, with how it is (ready, starting, not answering, not installed).
- **Any provider added there**: a server with OpenAI's audio interface
  (`/v1/audio/transcriptions`, `/v1/audio/speech`), such as OpenAI itself or one on your own
  computer. Presets fill in each one's fields.

**The voice module's servers** (intent 4fe0614c, its `module.md`) are installed one at a time,
when asked, and nothing is downloaded for one that is not. Each server's sheet on that page
has the line that installs it, which is this installer with `--voice-add <server>` (and, from
a release, the version installed, so it upgrades nothing); once installed, the line with
`--voice-remove <server>` takes it off with what it downloaded. Each downloads its model as it
first starts; the installer waits for it, says how long it took, and speaks a sentence in each
language and hears it back.

| Server | Hears | Speaks | Where | Downloads |
| --- | --- | --- | --- | --- |
| `speaches` | many languages (Whisper) | English (Kokoro) | CPU, amd64 and arm64 | about 2 GB |
| `parakeet` | English | | CPU | about 1 GB |
| `canary` | Portuguese, 24 other European languages | | CPU | about 1.1 GB |
| `kokoro-pt` | | European Portuguese, English words included | CPU | about 1.5 GB |
| `whisper-pt` | European Portuguese (INESC-ID's) | | NVIDIA card: holds about 2 GB of it | about 4 GB |
| `ming` | | English, four voices | NVIDIA card: about 2.5 GB while it speaks, let go after 15 minutes | about 4.6 GB |
| `breeze` | | English, a voice made from a description | NVIDIA card of 12 GB: about 4.5 GB while it speaks | about 6.7 GB |

The servers on a card need an NVIDIA driver of 580 or later, and a card of the 20 series or
later; the installer looks for one each time it runs, and refuses one that does not fit. Their
memory on the card is an estimate until measured on one. An instance that had the single
speech server before keeps it, as `speaches`.

**Languages** (intent 4fe0614c, its `concepts.md`): on the same page, a platform admin sets,
for each language, which provider and model hear it and which provider, model and voice speak
it, from every server on the list, installed or not. A person's "I speak" picks theirs. Until
languages are saved, they are what suits this computer: for each side of English and
European Portuguese, the first installed of its servers, best first (`ming` then `speaches`
to speak English; `parakeet` then `speaches` to hear it; `whisper-pt`, `canary`, `speaches`
to hear Portuguese; `kokoro-pt`, then Speaches' Brazilian voice, to speak it), else the best
of them, not installed, with its line. A language set to a server not installed is told so,
where it is used and by other apps.

**Other apps on this computer** (intent 4fe0614c): an app that speaks OpenAI's audio
interface reaches the instance's voice at `http://localhost:<port>/voice/v1`, with a key of
its own (Preferences → Voice → Other apps on this computer; shown once, and taken back there),
and a language as its model. With OpenAI's SDK:

```python
from openai import OpenAI
voice = OpenAI(base_url="http://localhost:8800/voice/v1", api_key="cpv_…")
text = voice.audio.transcriptions.create(model="pt-PT", file=open("said.wav", "rb")).text
voice.audio.speech.create(model="en", input="Hello.").write_to_file("hello.mp3")
```

Only those routes, `/models` and `/audio/voices` answer there: nothing of a speech server's
own. It is reached where the front door is, which is this computer unless `HTTP_BIND` says
otherwise.

**Checking a provider:** `infra/voice/conformance.sh <address> [key]` speaks a sentence and
hears it back. Inside an instance's network:

```bash
docker run --rm --network local-control-plane_net -v "$PWD/infra/voice:/v" \
  --entrypoint sh curlimages/curl:latest /v/conformance.sh http://voice:8000
```

## Signing in

People sign in with Rauthy, in tens of MB where Keycloak, which it replaced, needed most of a GB. The console
makes accounts itself (email, name, password), because Rauthy's own sign-up sets a first password by email and a
laptop has none; then people sign in on Rauthy's page.

An instance installed from a release that still had Keycloak moves to Rauthy when the line is run again: its
people come across with their passwords at Rauthy's first start, and nobody resets anything. What Keycloak kept
stays in its database, untouched (decision: intent c3c0c691, `trial-sign-in.md`).

## What it runs

`compose.yml` here includes the platform exactly as a box describes it
(`../deploy/compose.remote.yml` with `../stack/platform.yml`), with
`platform.yml` saying what differs on one computer, and one front door: the
box's nginx image, on plain http, bound to `127.0.0.1`. There are no
certificates, no registry, no GitHub runner and no landing page.

## Where things are

- **Its settings and secrets:** `~/.control-plane/<instance>/stack.env`, made
  from `.env.example` the first time and kept from then on. Its values are what
  its data is encrypted and signed with: keep the file.
- **Its data:** Docker volumes of the compose project `<instance>-control-plane`.
- **Several instances:** `INSTANCE=other ./infra/local/install.sh` makes another,
  beside the first, with its own port, env file and volumes.

## This computer as its runner

Runners → Add a runner gives one line to run here. Its agent reaches the
instance as `host.docker.internal`, names what it makes `control-plane-<instance>-…`
and answers on a port of its own, so the same computer can also stay a runner
of another control plane — the one you work in — without either touching what
the other made. Its images (the runner agent and the sandbox) are built here by
`install.sh`.

## Running it

| | |
|---|---|
| Start, or bring up to this checkout | `./infra/local/install.sh` |
| Add or take off a module | `./infra/local/install.sh control-plane conversations` |
| Stop, keeping everything | `./infra/local/install.sh --stop` |
| What a service says | `docker logs local-control-plane-<service>-1` |
| Sign in as the operator | the console's "Operator sign in", with `CONSOLE_PASSWORD` from the env file |

Proven by the `A local instance` workflow (`e2e/local/check.sh`), on the box
after every rollout of a change to what it installs and on every release: it
installs one from nothing, signs its first person up, adds the computer as its
runner, publishes an artifact from a sandbox there, and installs again over it.
