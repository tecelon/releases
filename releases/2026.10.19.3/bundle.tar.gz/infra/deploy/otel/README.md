# The telemetry collector

Everything the control plane emits is OpenTelemetry. That covers the services, each
worker's own Claude Code, and anything else pointed at port 4318. All of it
goes to one collector, and what the collector does with it is decided by **its
configuration file**. Nothing in the control plane's code names a destination.

[`collector.yaml`](collector.yaml) is the control plane's own configuration. It keeps the
last day in a file in the collector's volume and logs a line per batch. That's
enough to prove the chain works, and it isn't meant as a product.

## Sending it somewhere else

A deployment that already has a place for telemetry (an observability store, a
tracing service, another collector) replaces that file. It doesn't change any
code.

1. **Write a collector configuration** for your destination: an `otlp` receiver
   on 4317 and 4318 like the control plane's, and your exporters in its pipelines. The
   exporters available are those of
   `otel/opentelemetry-collector-contrib` at the version in
   `../compose.remote.yml`. Keep keys out of the file and reference them as
   `${env:NAME}`.
2. **Put the keys in an env file** of their own, `NAME=value` per line. Keep it
   next to the deployment's env file, not in this repository.
3. **Name both in the deployment's env file**, by absolute path on the machine
   that runs the rollout:

   ```ini
   OTEL_COLLECTOR_CONFIG=/var/lib/control-plane-deploy/collector.yaml
   OTEL_COLLECTOR_ENV=/var/lib/control-plane-deploy/collector.env
   ```

On the next rollout, [`place.sh`](place.sh) asks the collector image to
`validate` the configuration with those keys. If it passes, `place.sh` puts it
in the volume and the collector restarts on it. If it fails, the rollout stops
with the collector's reason, and the running collector keeps the configuration
it had. Both rollout paths go through it: `../deploy.sh` and
`../../stack/provision.sh`.

To go back to the control plane's configuration, empty the two lines.

## What arrives

- **Traces from the services:** a span per run and per tool call
  (`OTEL_EXPORTER_OTLP_ENDPOINT` in the compose file).
- **Each worker's Claude Code:** its own metrics and logs.
  `OTEL_WORKER_ENDPOINT` says where a worker on another machine reaches the
  collector.
- **Every piece of work carries a W3C trace id.** It travels in commit trailers
  (`Control-Plane-Trace`), pull requests and the resource attributes of everything a
  session emits. That id joins a session's telemetry to the change it made and
  the rollout that shipped it, wherever the telemetry is stored.
